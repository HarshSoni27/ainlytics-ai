import { mergePosts } from "./csv";
import { generateDemoPosts } from "./demoData";
import type { DataSource, Post } from "./types";

/**
 * Tiny client-side data store backed by localStorage.
 *
 * Why not plain React state + useEffect? Reading localStorage during render would make
 * the server HTML and the first browser render differ (a hydration error). With
 * `useSyncExternalStore` the server (and the first client render) always see the
 * "loading" state, and the real data appears right after hydration.
 */

const STORAGE_KEY = "ainlytics-ai:data:v1";
const STORAGE_VERSION = 1;

export interface DataState {
  status: "loading" | "ready";
  posts: Post[];
  source: DataSource;
  updatedAt: string | null;
  /** A non-fatal problem with reading or saving data, shown to the user. */
  storageError: string | null;
}

export interface ActionResult {
  ok: boolean;
  error?: string;
}

interface StoredData {
  version: number;
  source: DataSource;
  posts: Post[];
  updatedAt: string;
}

const LOADING_STATE: DataState = {
  status: "loading",
  posts: [],
  source: "empty",
  updatedAt: null,
  storageError: null,
};

let state: DataState = LOADING_STATE;
let initialized = false;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

// ---------- validation of whatever is in storage ----------

function isFiniteCount(n: unknown): n is number {
  return typeof n === "number" && Number.isFinite(n) && n >= 0;
}

function isPost(x: unknown): x is Post {
  if (typeof x !== "object" || x === null) return false;
  const p = x as Record<string, unknown>;
  return (
    typeof p.id === "string" &&
    typeof p.date === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(p.date) &&
    typeof p.platform === "string" &&
    p.platform.length > 0 &&
    typeof p.caption === "string" &&
    typeof p.contentType === "string" &&
    isFiniteCount(p.likes) &&
    isFiniteCount(p.comments) &&
    isFiniteCount(p.shares) &&
    isFiniteCount(p.reach) &&
    isFiniteCount(p.impressions)
  );
}

function demoState(storageError: string | null): DataState {
  return {
    status: "ready",
    posts: generateDemoPosts(),
    source: "demo",
    updatedAt: new Date().toISOString(),
    storageError,
  };
}

function readFromStorage(): DataState {
  let raw: string | null;
  try {
    raw = window.localStorage.getItem(STORAGE_KEY);
  } catch {
    // Storage blocked (private mode, browser settings). App still works in memory.
    return demoState(
      "Browser storage is unavailable, so your data won't be saved between visits.",
    );
  }

  if (raw === null) {
    // First launch: seed demo data and save it.
    const seeded = demoState(null);
    return writeToStorage(seeded);
  }

  try {
    const parsed = JSON.parse(raw) as Partial<StoredData>;
    if (
      parsed.version !== STORAGE_VERSION ||
      !Array.isArray(parsed.posts) ||
      (parsed.source !== "demo" &&
        parsed.source !== "imported" &&
        parsed.source !== "empty")
    ) {
      throw new Error("Unexpected format");
    }
    const posts = parsed.posts.filter(isPost);
    const dropped = parsed.posts.length - posts.length;
    return {
      status: "ready",
      posts,
      source: parsed.source,
      updatedAt: typeof parsed.updatedAt === "string" ? parsed.updatedAt : null,
      storageError:
        dropped > 0
          ? `${dropped} saved post${dropped > 1 ? "s were" : " was"} damaged and skipped.`
          : null,
    };
  } catch {
    return writeToStorage(
      demoState("Saved data could not be read, so it was reset to the demo data."),
    );
  }
}

/** Saves `next` and returns it (with `storageError` set if saving failed). */
function writeToStorage(next: DataState): DataState {
  const payload: StoredData = {
    version: STORAGE_VERSION,
    source: next.source,
    posts: next.posts,
    updatedAt: next.updatedAt ?? new Date().toISOString(),
  };
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    return next;
  } catch {
    return {
      ...next,
      storageError:
        next.storageError ??
        "Couldn't save to browser storage (it may be full or blocked). Your changes will be lost when you refresh.",
    };
  }
}

// ---------- store plumbing for useSyncExternalStore ----------

function init() {
  if (initialized || typeof window === "undefined") return;
  initialized = true;
  state = readFromStorage();
  // Keep multiple open tabs in sync.
  window.addEventListener("storage", (e) => {
    if (e.key === STORAGE_KEY || e.key === null) {
      state = readFromStorage();
      emit();
    }
  });
}

export function subscribe(listener: () => void): () => void {
  init();
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function getSnapshot(): DataState {
  init();
  return state;
}

export function getServerSnapshot(): DataState {
  return LOADING_STATE;
}

// ---------- actions ----------

function commit(next: Omit<DataState, "status" | "updatedAt" | "storageError">) {
  state = writeToStorage({
    status: "ready",
    posts: next.posts,
    source: next.source,
    updatedAt: new Date().toISOString(),
    storageError: null,
  });
  emit();
  return state.storageError;
}

export type ImportMode = "replace" | "append";

export interface ImportResult extends ActionResult {
  added: number;
  duplicates: number;
  total: number;
}

/** Imports validated posts, either replacing everything or adding to what's there. */
export function importPosts(incoming: Post[], mode: ImportMode): ImportResult {
  if (incoming.length === 0) {
    return {
      ok: false,
      error: "There are no valid rows to import.",
      added: 0,
      duplicates: 0,
      total: state.posts.length,
    };
  }

  let posts: Post[];
  let added = incoming.length;
  let duplicates = 0;

  // Appending to demo data would mix fake and real numbers, so demo is always replaced.
  if (mode === "append" && state.source === "imported") {
    const merged = mergePosts(state.posts, incoming);
    posts = merged.merged;
    added = merged.added;
    duplicates = merged.duplicates;
  } else {
    posts = incoming;
  }

  const storageError = commit({ posts, source: "imported" });
  return {
    ok: storageError === null,
    error: storageError ?? undefined,
    added,
    duplicates,
    total: posts.length,
  };
}

export function resetDemo(): ActionResult {
  const storageError = commit({ posts: generateDemoPosts(), source: "demo" });
  return { ok: storageError === null, error: storageError ?? undefined };
}

export function clearAll(): ActionResult {
  const storageError = commit({ posts: [], source: "empty" });
  return { ok: storageError === null, error: storageError ?? undefined };
}
