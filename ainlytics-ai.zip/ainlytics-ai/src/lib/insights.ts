import { formatDate, formatPercent, truncate, WEEKDAYS } from "./format";
import {
  addDays,
  averageEngagementRate,
  buildPlatformStats,
  dateRange,
  dayOfWeek,
  daysBetween,
  engagementRate,
  summarize,
} from "./metrics";
import type { Post } from "./types";

/**
 * LOCAL insights engine. Everything here is plain, rule-based statistics computed in the
 * browser from the current dataset. It is NOT an AI model and the UI labels it as such.
 */

export interface RankedPost {
  post: Post;
  rate: number;
}

export interface Pattern {
  id: string;
  title: string;
  detail: string;
  tone: "positive" | "negative" | "neutral";
}

export interface Suggestion {
  id: string;
  title: string;
  detail: string;
}

export interface PostIdea {
  id: string;
  title: string;
  platform: string;
  format: string;
  caption: string;
  rationale: string;
}

export interface LocalInsights {
  hasEnoughData: boolean;
  headline: string;
  best: RankedPost[];
  worst: RankedPost[];
  patterns: Pattern[];
  suggestions: Suggestion[];
  ideas: PostIdea[];
  /** Words that appear more often in top-performing captions. */
  themeWords: string[];
  caveats: string[];
}

const MIN_RATED_POSTS = 5;
const MIN_GROUP_SIZE = 3;
/** A difference must be at least this large (as a fraction) to be called a pattern. */
const NOTABLE = 0.08;

const STOPWORDS = new Set(
  (
    "a about after all also an and any are as at be been but by can did do does for from get got had has have " +
    "he her here him his how i if in into is it its just like more most my new no not now of off on one or our " +
    "out over she so some than that the their them then there these they this to too up us was we were what when " +
    "where which who why will with you your yours tell think hint starts short story thread honest lessons part " +
    "everything need know under minute simple guide quick tip time limited offer ends sunday said asked team " +
    "behind scenes swipe made makes drop alert poll vote comments agree disagree save later take hot did learn " +
    "see saw seen look looks want wanted next cover covers show shows way ways really very much many make " +
    "don doesn didn isn aren wasn won can't cant dont"
  ).split(/\s+/),
);

const MIN_WORD_LENGTH = 4;

// ---------- small helpers ----------

function groupBy<T>(items: T[], key: (item: T) => string): Map<string, T[]> {
  const map = new Map<string, T[]>();
  for (const item of items) {
    const k = key(item);
    const list = map.get(k);
    if (list) list.push(item);
    else map.set(k, [item]);
  }
  return map;
}

function mean(values: number[]): number {
  return values.length === 0 ? 0 : values.reduce((a, b) => a + b, 0) / values.length;
}

function pct(fraction: number): string {
  return `${Math.round(Math.abs(fraction) * 100)}%`;
}

function tokenize(caption: string): string[] {
  const cleaned = caption
    .toLowerCase()
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/[#@][\w]+/g, " ")
    .replace(/['’][a-z]*/g, " "); // drop contractions: it's -> it, don't -> don
  const words = cleaned.match(/[a-z]+/g) ?? [];
  return words.filter((w) => w.length >= MIN_WORD_LENGTH && !STOPWORDS.has(w));
}

// ---------- main entry point ----------

export function analyzeLocally(posts: Post[]): LocalInsights {
  const rated = posts.filter((p) => p.reach > 0);
  const hasEnoughData = rated.length >= MIN_RATED_POSTS;

  const ranked: RankedPost[] = rated
    .map((post) => ({ post, rate: engagementRate(post) }))
    .sort((a, b) => b.rate - a.rate);

  const best = ranked.slice(0, 3);
  // Avoid showing the same post as both best and worst in tiny datasets.
  const worst = ranked
    .slice(Math.max(best.length, ranked.length - 3))
    .reverse();

  const caveats: string[] = [
    "These are rule-based statistics, not predictions. Patterns show correlation, not proof that a change will cause better results.",
  ];
  const zeroReach = posts.length - rated.length;
  if (zeroReach > 0) {
    caveats.push(
      `${zeroReach} post${zeroReach > 1 ? "s have" : " has"} zero reach and ${zeroReach > 1 ? "are" : "is"} excluded from engagement-rate comparisons.`,
    );
  }

  if (!hasEnoughData) {
    return {
      hasEnoughData,
      headline:
        posts.length === 0
          ? "No data yet. Upload a CSV or reset the demo data to see insights."
          : `Only ${rated.length} post${rated.length === 1 ? "" : "s"} with reach found. Add at least ${MIN_RATED_POSTS} for meaningful patterns.`,
      best,
      worst,
      patterns: [],
      suggestions: [],
      ideas: [],
      themeWords: [],
      caveats,
    };
  }

  // Each post's rate relative to its own platform's average. 1.0 = typical for that platform.
  // This stops platform differences (e.g. TikTok vs X) from masquerading as format effects.
  const platformAvg = new Map<string, number>();
  for (const [platform, group] of groupBy(rated, (p) => p.platform)) {
    platformAvg.set(platform, averageEngagementRate(group));
  }
  const index = (p: Post): number => {
    const avg = platformAvg.get(p.platform) ?? 0;
    return avg > 0 ? engagementRate(p) / avg : 1;
  };
  const groupIndex = (group: Post[]): number => mean(group.map(index));

  const overall = summarize(posts);
  const patterns: Pattern[] = [];
  const suggestions: Suggestion[] = [];

  // ----- Platform -----
  const platformStats = buildPlatformStats(rated).filter((s) => s.posts >= MIN_GROUP_SIZE);
  let bestPlatform: string | null = null;
  let weakestPlatform: string | null = null;
  if (platformStats.length >= 2) {
    const top = platformStats[0];
    const bottom = platformStats[platformStats.length - 1];
    bestPlatform = top.platform;
    weakestPlatform = bottom.platform;
    patterns.push({
      id: "platform",
      title: `${top.platform} has your highest engagement rate`,
      detail: `${top.platform} averages ${formatPercent(top.engagementRate)} across ${top.posts} posts, while ${bottom.platform} averages ${formatPercent(bottom.engagementRate)} across ${bottom.posts}. Your overall average is ${formatPercent(overall.avgEngagementRate)}.`,
      tone: "positive",
    });
  }

  // ----- Content type -----
  let bestType: { name: string; idx: number } | null = null;
  const typeGroups = Array.from(groupBy(rated, (p) => p.contentType))
    .filter(([, g]) => g.length >= MIN_GROUP_SIZE)
    .map(([name, g]) => ({ name, n: g.length, idx: groupIndex(g) }))
    .sort((a, b) => b.idx - a.idx);
  if (typeGroups.length >= 2) {
    const top = typeGroups[0];
    const bottom = typeGroups[typeGroups.length - 1];
    if (top.idx - 1 >= NOTABLE) {
      bestType = { name: top.name, idx: top.idx };
      patterns.push({
        id: "type-best",
        title: `${top.name} posts outperform`,
        detail: `${top.name} posts run ${pct(top.idx - 1)} above the average for their platform (${top.n} posts).`,
        tone: "positive",
      });
      suggestions.push({
        id: "more-type",
        title: `Publish more ${top.name} content`,
        detail: `${top.name} is your strongest format (+${pct(top.idx - 1)} vs platform average, ${top.n} posts). Try shifting a few posts per week to this format.`,
      });
    }
    if (1 - bottom.idx >= NOTABLE && bottom.name !== top.name) {
      patterns.push({
        id: "type-worst",
        title: `${bottom.name} posts underperform`,
        detail: `${bottom.name} posts run ${pct(1 - bottom.idx)} below the average for their platform (${bottom.n} posts).`,
        tone: "negative",
      });
      suggestions.push({
        id: "rework-type",
        title: `Rework your ${bottom.name} posts`,
        detail: `${bottom.name} is your weakest format (−${pct(1 - bottom.idx)} vs platform average). Test stronger hooks or swap some of these for ${bestType?.name ?? "your best-performing format"}.`,
      });
    }
  }

  // ----- Day of week -----
  let bestDay: { name: string; idx: number } | null = null;
  const dayGroups = Array.from(groupBy(rated, (p) => String(dayOfWeek(p.date))))
    .filter(([, g]) => g.length >= MIN_GROUP_SIZE)
    .map(([d, g]) => ({ name: WEEKDAYS[Number(d)], n: g.length, idx: groupIndex(g) }))
    .sort((a, b) => b.idx - a.idx);
  if (dayGroups.length >= 2) {
    const top = dayGroups[0];
    const bottom = dayGroups[dayGroups.length - 1];
    if (top.idx - 1 >= NOTABLE) {
      bestDay = { name: top.name, idx: top.idx };
      patterns.push({
        id: "day-best",
        title: `${top.name}s are your strongest day`,
        detail: `Posts published on ${top.name}s run ${pct(top.idx - 1)} above their platform's average (${top.n} posts).`,
        tone: "positive",
      });
      suggestions.push({
        id: "best-day",
        title: `Schedule important posts on ${top.name}s`,
        detail: `${top.name} posts perform +${pct(top.idx - 1)} better than average. Save launches and promotions for that day.`,
      });
    }
    if (1 - bottom.idx >= NOTABLE) {
      patterns.push({
        id: "day-worst",
        title: `${bottom.name}s are your weakest day`,
        detail: `Posts published on ${bottom.name}s run ${pct(1 - bottom.idx)} below their platform's average (${bottom.n} posts).`,
        tone: "negative",
      });
    }
  }

  // ----- Caption features -----
  const captionFeature = (
    test: (p: Post) => boolean,
  ): { yesIdx: number; noIdx: number; yesN: number; noN: number } | null => {
    const yes = rated.filter(test);
    const no = rated.filter((p) => !test(p));
    if (yes.length < MIN_GROUP_SIZE || no.length < MIN_GROUP_SIZE) return null;
    return {
      yesIdx: groupIndex(yes),
      noIdx: groupIndex(no),
      yesN: yes.length,
      noN: no.length,
    };
  };

  const question = captionFeature((p) => p.caption.includes("?"));
  if (question) {
    const diff = question.yesIdx / question.noIdx - 1;
    if (Math.abs(diff) >= NOTABLE) {
      const positive = diff > 0;
      patterns.push({
        id: "question",
        title: positive
          ? "Captions with a question get more engagement"
          : "Captions with a question get less engagement",
        detail: `Posts containing a question mark score ${pct(diff)} ${positive ? "higher" : "lower"} than posts without one, after adjusting for platform (${question.yesN} vs ${question.noN} posts).`,
        tone: positive ? "positive" : "negative",
      });
      if (positive) {
        suggestions.push({
          id: "ask-question",
          title: "Ask your audience a question",
          detail: `Question-style captions earn about ${pct(diff)} more engagement. End more posts with a direct question or a clear call to comment.`,
        });
      }
    }
  }

  const hashtags = captionFeature((p) => p.caption.includes("#"));
  if (hashtags) {
    const diff = hashtags.yesIdx / hashtags.noIdx - 1;
    if (Math.abs(diff) >= NOTABLE) {
      const positive = diff > 0;
      patterns.push({
        id: "hashtags",
        title: positive ? "Hashtags are helping" : "Hashtags are not helping",
        detail: `Posts with hashtags score ${pct(diff)} ${positive ? "higher" : "lower"} than posts without, after adjusting for platform (${hashtags.yesN} vs ${hashtags.noN} posts).`,
        tone: positive ? "positive" : "negative",
      });
      suggestions.push({
        id: "hashtags",
        title: positive ? "Keep using relevant hashtags" : "Use fewer hashtags",
        detail: positive
          ? `Posts with hashtags earn about ${pct(diff)} more engagement. Keep 2–4 specific hashtags rather than long lists.`
          : `Posts without hashtags do about ${pct(diff)} better. Try dropping hashtags on a few posts and compare.`,
      });
    }
  }

  const lengths = rated.map((p) => p.caption.length).sort((a, b) => a - b);
  const medianLength = lengths[Math.floor(lengths.length / 2)];
  const lengthFeature = captionFeature((p) => p.caption.length < medianLength);
  if (lengthFeature) {
    const diff = lengthFeature.yesIdx / lengthFeature.noIdx - 1;
    if (Math.abs(diff) >= NOTABLE) {
      const shortWins = diff > 0;
      patterns.push({
        id: "length",
        title: shortWins ? "Shorter captions do better" : "Longer captions do better",
        detail: `Captions under ${medianLength} characters score ${pct(diff)} ${shortWins ? "higher" : "lower"} than longer ones, after adjusting for platform.`,
        tone: "neutral",
      });
      suggestions.push({
        id: "length",
        title: shortWins ? "Tighten your captions" : "Give posts more context",
        detail: shortWins
          ? `Lead with the hook and cut the rest; captions under ~${medianLength} characters perform better.`
          : `Longer captions (over ~${medianLength} characters) perform better. Add a little more story or detail.`,
      });
    }
  }

  // ----- Trend -----
  const range = dateRange(rated);
  if (range) {
    const span = daysBetween(range.min, range.max);
    let recent: Post[] = [];
    let previous: Post[] = [];
    let windowLabel = "";
    if (span >= 60) {
      const cut1 = addDays(range.max, -30);
      const cut2 = addDays(range.max, -60);
      recent = rated.filter((p) => p.date > cut1);
      previous = rated.filter((p) => p.date > cut2 && p.date <= cut1);
      windowLabel = "the previous 30 days";
    } else if (span >= 14) {
      const mid = addDays(range.min, Math.floor(span / 2));
      recent = rated.filter((p) => p.date > mid);
      previous = rated.filter((p) => p.date <= mid);
      windowLabel = "the first half of your data";
    }
    if (recent.length >= MIN_GROUP_SIZE && previous.length >= MIN_GROUP_SIZE) {
      const diff = groupIndex(recent) / groupIndex(previous) - 1;
      if (Math.abs(diff) >= 0.05) {
        const up = diff > 0;
        patterns.push({
          id: "trend",
          title: up ? "Engagement is trending up" : "Engagement is trending down",
          detail: `Recent posts score ${pct(diff)} ${up ? "higher" : "lower"} than ${windowLabel} (${recent.length} vs ${previous.length} posts, platform-adjusted).`,
          tone: up ? "positive" : "negative",
        });
        suggestions.push({
          id: "trend",
          title: up ? "Keep your current momentum" : "Review your recent content",
          detail: up
            ? "Recent content is working better. Note what changed (formats, topics, timing) and repeat it."
            : "Recent posts are underperforming earlier ones. Compare them with your top posts for format, topic and timing differences.",
        });
      }
    }
  }

  // ----- Words that show up more in top-performing captions -----
  // Ranked by platform-adjusted score so platform differences don't leak into themes.
  const rankedByIndex: RankedPost[] = rated
    .map((post) => ({ post, rate: index(post) }))
    .sort((a, b) => b.rate - a.rate);
  const themeWords = findThemeWords(rankedByIndex);
  if (themeWords.length > 0) {
    patterns.push({
      id: "themes",
      title: "Topics that show up in your best posts",
      detail: `These words appear more often in your top-performing captions than in the rest: ${themeWords.join(", ")}.`,
      tone: "neutral",
    });
  }

  // ----- Data quality -----
  if (zeroReach > 0) {
    suggestions.push({
      id: "zero-reach",
      title: "Check posts with zero reach",
      detail: `${zeroReach} post${zeroReach > 1 ? "s" : ""} report no reach. If that is a data export problem, fix it so the engagement rate can be calculated.`,
    });
  }

  if (patterns.length === 0) {
    patterns.push({
      id: "none",
      title: "No strong patterns yet",
      detail:
        "Your formats, posting days and caption styles all perform similarly, or there aren't enough posts in each group (at least 3) to compare. Upload more posts to find patterns.",
      tone: "neutral",
    });
  }

  if (suggestions.length === 0) {
    suggestions.push({
      id: "more-data",
      title: "Collect more data before changing strategy",
      detail:
        "Nothing stands out yet. Keep posting a mix of formats and days, then re-upload your analytics to look for differences.",
    });
  }

  // ----- Post ideas (template-based) -----
  const ideas = buildIdeas({
    ranked,
    rated,
    bestPlatform,
    weakestPlatform,
    bestDay: bestDay?.name ?? null,
    themeWords,
    questionHelps: question ? question.yesIdx / question.noIdx - 1 >= NOTABLE : false,
    overallRate: overall.avgEngagementRate,
    platformStats,
  });

  const topPlatform = platformStats[0];
  const headline = topPlatform
    ? `Your ${overall.totalPosts} posts average ${formatPercent(overall.avgEngagementRate)} engagement. ${topPlatform.platform} leads at ${formatPercent(topPlatform.engagementRate)}.`
    : `Your ${overall.totalPosts} posts average ${formatPercent(overall.avgEngagementRate)} engagement.`;

  return {
    hasEnoughData,
    headline,
    best,
    worst,
    patterns,
    suggestions: suggestions.slice(0, 6),
    ideas,
    themeWords,
    caveats,
  };
}

// ---------- themes ----------

function findThemeWords(ranked: RankedPost[]): string[] {
  const topCount = Math.max(MIN_GROUP_SIZE, Math.ceil(ranked.length / 4));
  const top = ranked.slice(0, topCount);
  const rest = ranked.slice(topCount);
  if (top.length < MIN_GROUP_SIZE || rest.length < MIN_GROUP_SIZE) return [];

  const docFreq = (group: RankedPost[]): Map<string, number> => {
    const freq = new Map<string, number>();
    for (const { post } of group) {
      for (const w of new Set(tokenize(post.caption))) {
        freq.set(w, (freq.get(w) ?? 0) + 1);
      }
    }
    return freq;
  };
  const topFreq = docFreq(top);
  const restFreq = docFreq(rest);

  return Array.from(topFreq.entries())
    .filter(([, count]) => count >= 2)
    .map(([word, count]) => ({
      word,
      lift: count / top.length - (restFreq.get(word) ?? 0) / rest.length,
    }))
    .filter((w) => w.lift > 0.15)
    .sort((a, b) => b.lift - a.lift)
    .slice(0, 4)
    .map((w) => w.word);
}

// ---------- ideas ----------

interface IdeaInput {
  ranked: RankedPost[];
  rated: Post[];
  bestPlatform: string | null;
  weakestPlatform: string | null;
  bestDay: string | null;
  themeWords: string[];
  questionHelps: boolean;
  overallRate: number;
  platformStats: { platform: string; engagementRate: number; posts: number }[];
}

/**
 * The best-performing content type ON THAT PLATFORM, using only formats the platform
 * actually has in the data (so we never suggest, say, a Reel on X).
 */
function bestFormatFor(platform: string, rated: Post[]): string {
  const onPlatform = rated.filter((p) => p.platform === platform);
  const groups = Array.from(groupBy(onPlatform, (p) => p.contentType))
    .filter(([, g]) => g.length >= 2)
    .map(([type, g]) => ({ type, rate: averageEngagementRate(g) }))
    .sort((a, b) => b.rate - a.rate);
  if (groups.length > 0) return groups[0].type;

  const counts = Array.from(groupBy(onPlatform, (p) => p.contentType))
    .map(([type, g]) => ({ type, n: g.length }))
    .sort((a, b) => b.n - a.n);
  return counts[0]?.type ?? "Post";
}

function buildIdeas(input: IdeaInput): PostIdea[] {
  const { ranked, rated, bestPlatform, weakestPlatform, bestDay, themeWords } = input;
  const top = ranked[0];
  const theme = themeWords[0] ?? null;

  const topMultiple =
    input.overallRate > 0 ? (top.rate / input.overallRate).toFixed(1) : null;

  const ideas: PostIdea[] = [];

  // 1. Build on the top post.
  ideas.push({
    id: "idea-followup",
    title: "Follow up on your top post",
    platform: top.post.platform,
    format: top.post.contentType,
    caption: `Part 2: you loved "${truncate(top.post.caption, 70)}" — here's what we didn't show last time. What should we cover next?`,
    rationale: `Your best post (${formatDate(top.post.date)} on ${top.post.platform}) reached ${formatPercent(top.rate)} engagement${topMultiple ? `, about ${topMultiple}× your average` : ""}. Sequels reuse what already resonates.`,
  });

  // 2. Question-led post on the strongest platform and day.
  const questionPlatform = bestPlatform ?? top.post.platform;
  ideas.push({
    id: "idea-question",
    title: "Ask your audience a question",
    platform: questionPlatform,
    format: bestFormatFor(questionPlatform, rated),
    caption: theme
      ? `We're planning more about ${theme}. What do you most want to know? Tell us in the comments 👇`
      : `What should we post more of? Tell us in the comments 👇`,
    rationale: input.questionHelps
      ? `Question captions earn more engagement in your data.${bestDay ? ` Publish on a ${bestDay}, your strongest day.` : ""}`
      : `A low-effort experiment: questions invite comments, which count toward engagement.${bestDay ? ` Try it on a ${bestDay}, your strongest day.` : ""}`,
  });

  // 3. Rework the weakest platform using its own best format.
  const weakPlatform =
    weakestPlatform && weakestPlatform !== questionPlatform
      ? weakestPlatform
      : (input.platformStats[input.platformStats.length - 1]?.platform ?? top.post.platform);
  const weakStat = input.platformStats.find((s) => s.platform === weakPlatform);
  ideas.push({
    id: "idea-rework",
    title: `Re-test ${weakPlatform} with a sharper hook`,
    platform: weakPlatform,
    format: bestFormatFor(weakPlatform, rated),
    caption: theme
      ? `Take your strongest topic ("${theme}") and rewrite it natively for ${weakPlatform}: a stronger first line, one clear takeaway, one question.`
      : `Take your best-performing post and rewrite it natively for ${weakPlatform}: a stronger first line, one clear takeaway, one question.`,
    rationale: weakStat
      ? `${weakPlatform} averages ${formatPercent(weakStat.engagementRate)} vs ${formatPercent(input.overallRate)} overall, so it has the most room to improve. Run this as a 2–3 post test.`
      : `Test a stronger hook on a platform that is lagging, then compare results.`,
  });

  return ideas;
}

// ---------- payload for the optional AI route ----------

export interface AiPayload {
  period: { start: string; end: string };
  totals: {
    posts: number;
    likes: number;
    comments: number;
    shares: number;
    reach: number;
    impressions: number;
    avgEngagementRatePercent: number;
  };
  platforms: { platform: string; posts: number; avgEngagementRatePercent: number }[];
  topPosts: AiPostSample[];
  bottomPosts: AiPostSample[];
}

export interface AiPostSample {
  date: string;
  platform: string;
  contentType: string;
  caption: string;
  engagementRatePercent: number;
  reach: number;
}

/** A compact summary (not the whole dataset) is all that ever leaves the browser. */
export function buildAiPayload(posts: Post[]): AiPayload | null {
  const rated = posts.filter((p) => p.reach > 0);
  const range = dateRange(posts);
  if (!range || rated.length === 0) return null;

  const s = summarize(posts);
  const ranked = rated
    .map((post) => ({ post, rate: engagementRate(post) }))
    .sort((a, b) => b.rate - a.rate);
  const sample = ({ post, rate }: RankedPost): AiPostSample => ({
    date: post.date,
    platform: post.platform,
    contentType: post.contentType,
    caption: truncate(post.caption, 140),
    engagementRatePercent: Math.round(rate * 100) / 100,
    reach: post.reach,
  });

  return {
    period: { start: range.min, end: range.max },
    totals: {
      posts: s.totalPosts,
      likes: s.totalLikes,
      comments: s.totalComments,
      shares: s.totalShares,
      reach: s.totalReach,
      impressions: s.totalImpressions,
      avgEngagementRatePercent: Math.round(s.avgEngagementRate * 100) / 100,
    },
    platforms: buildPlatformStats(rated).map((p) => ({
      platform: p.platform,
      posts: p.posts,
      avgEngagementRatePercent: p.engagementRate,
    })),
    topPosts: ranked.slice(0, 5).map(sample),
    bottomPosts: ranked.slice(-5).reverse().map(sample),
  };
}

export interface AiInsightsResponse {
  summary: string;
  patterns: string[];
  suggestions: string[];
  postIdeas: { title: string; platform: string; idea: string }[];
}
