import type {
  MetricsSummary,
  PlatformStat,
  Post,
  PostFilters,
  TrendPoint,
} from "./types";

/**
 * THE engagement formula. Every screen uses this one function so numbers never disagree.
 *
 *   engagement rate = (likes + comments + shares) / reach * 100
 *
 * If reach is 0 (or not a finite number) the rate is undefined, so we return 0
 * instead of NaN/Infinity. Callers that average rates skip those posts
 * (see `averageEngagementRate`).
 */
export function engagementRate(
  p: Pick<Post, "likes" | "comments" | "shares" | "reach">,
): number {
  if (!Number.isFinite(p.reach) || p.reach <= 0) return 0;
  const interactions = p.likes + p.comments + p.shares;
  return (interactions / p.reach) * 100;
}

export function interactionsOf(
  p: Pick<Post, "likes" | "comments" | "shares">,
): number {
  return p.likes + p.comments + p.shares;
}

/**
 * Average engagement rate = mean of per-post rates, over posts with reach > 0.
 * Posts with zero reach have no defined rate, so they are left out of the average
 * (rather than dragging it down with a fake 0%).
 */
export function averageEngagementRate(posts: Post[]): number {
  const withReach = posts.filter((p) => p.reach > 0);
  if (withReach.length === 0) return 0;
  const sum = withReach.reduce((acc, p) => acc + engagementRate(p), 0);
  return sum / withReach.length;
}

export function summarize(posts: Post[]): MetricsSummary {
  let totalLikes = 0;
  let totalComments = 0;
  let totalShares = 0;
  let totalReach = 0;
  let totalImpressions = 0;
  let zeroReachPosts = 0;

  for (const p of posts) {
    totalLikes += p.likes;
    totalComments += p.comments;
    totalShares += p.shares;
    totalReach += p.reach;
    totalImpressions += p.impressions;
    if (p.reach <= 0) zeroReachPosts += 1;
  }

  return {
    totalPosts: posts.length,
    totalLikes,
    totalComments,
    totalShares,
    totalReach,
    totalImpressions,
    totalInteractions: totalLikes + totalComments + totalShares,
    avgEngagementRate: averageEngagementRate(posts),
    zeroReachPosts,
  };
}

// ---------- Dates (plain YYYY-MM-DD strings, handled in UTC so nothing shifts) ----------

const DAY_MS = 86_400_000;

export function dateToMs(date: string): number {
  const [y, m, d] = date.split("-").map(Number);
  return Date.UTC(y, m - 1, d);
}

export function msToDate(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

export function addDays(date: string, days: number): string {
  return msToDate(dateToMs(date) + days * DAY_MS);
}

export function daysBetween(a: string, b: string): number {
  return Math.round((dateToMs(b) - dateToMs(a)) / DAY_MS);
}

/** Day of week 0 (Sunday) – 6 (Saturday) for a YYYY-MM-DD date. */
export function dayOfWeek(date: string): number {
  return new Date(dateToMs(date)).getUTCDay();
}

/** Monday of the week containing `date`. */
function weekStart(date: string): string {
  const dow = dayOfWeek(date); // 0 = Sun
  const offset = dow === 0 ? -6 : 1 - dow;
  return addDays(date, offset);
}

export function dateRange(posts: Post[]): { min: string; max: string } | null {
  if (posts.length === 0) return null;
  let min = posts[0].date;
  let max = posts[0].date;
  for (const p of posts) {
    if (p.date < min) min = p.date;
    if (p.date > max) max = p.date;
  }
  return { min, max };
}

// ---------- Filtering ----------

export const ALL_PLATFORMS = "all";

export function filterPosts(posts: Post[], f: PostFilters): Post[] {
  return posts.filter((p) => {
    if (f.platform !== ALL_PLATFORMS && p.platform !== f.platform) return false;
    if (f.from && p.date < f.from) return false;
    if (f.to && p.date > f.to) return false;
    return true;
  });
}

export function uniquePlatforms(posts: Post[]): string[] {
  return Array.from(new Set(posts.map((p) => p.platform))).sort((a, b) =>
    a.localeCompare(b),
  );
}

// ---------- Chart data ----------

const SHORT_MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

export function shortDateLabel(date: string): string {
  const [, m, d] = date.split("-").map(Number);
  return `${SHORT_MONTHS[m - 1]} ${d}`;
}

/**
 * Groups posts into daily buckets when the data spans ≤ 31 days, otherwise weekly
 * (weeks start on Monday). Each bucket's rate uses the same averaging as the cards.
 */
export function buildTrend(posts: Post[]): {
  points: TrendPoint[];
  granularity: "day" | "week";
} {
  const range = dateRange(posts);
  if (!range) return { points: [], granularity: "day" };

  const granularity = daysBetween(range.min, range.max) <= 31 ? "day" : "week";
  const buckets = new Map<string, Post[]>();

  for (const p of posts) {
    const key = granularity === "day" ? p.date : weekStart(p.date);
    const list = buckets.get(key);
    if (list) list.push(p);
    else buckets.set(key, [p]);
  }

  const points = Array.from(buckets.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, group]) => {
      const s = summarize(group);
      return {
        date,
        label:
          granularity === "day"
            ? shortDateLabel(date)
            : `Wk of ${shortDateLabel(date)}`,
        posts: group.length,
        engagementRate: round2(s.avgEngagementRate),
        reach: s.totalReach,
        interactions: s.totalInteractions,
      };
    });

  return { points, granularity };
}

export function buildPlatformStats(posts: Post[]): PlatformStat[] {
  const groups = new Map<string, Post[]>();
  for (const p of posts) {
    const list = groups.get(p.platform);
    if (list) list.push(p);
    else groups.set(p.platform, [p]);
  }
  return Array.from(groups.entries())
    .map(([platform, group]) => {
      const s = summarize(group);
      return {
        platform,
        posts: group.length,
        engagementRate: round2(s.avgEngagementRate),
        reach: s.totalReach,
        interactions: s.totalInteractions,
      };
    })
    .sort((a, b) => b.engagementRate - a.engagementRate);
}

export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
