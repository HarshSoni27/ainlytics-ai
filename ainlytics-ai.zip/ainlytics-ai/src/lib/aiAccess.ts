/**
 * Server-side rules for who may use the optional AI endpoint.
 * Pure functions (no Next.js imports) so they can be unit tested.
 *
 * The endpoint is OFF unless ALL of these hold:
 *   1. ANTHROPIC_API_KEY is set
 *   2. ENABLE_AI_INSIGHTS=true is set (an explicit opt-in, so a key alone never switches it on)
 *   3. In a production build, AI_ACCESS_CODE is also set, so a public website can never
 *      expose a paid endpoint to anonymous visitors.
 */

import { createHash, timingSafeEqual } from "node:crypto";

type Env = Record<string, string | undefined>;

export interface AiStatus {
  enabled: boolean;
  /** Visitors must type the access code before they can generate insights. */
  requiresCode: boolean;
}

export function getAiStatus(env: Env = process.env): AiStatus {
  const hasKey = Boolean(env.ANTHROPIC_API_KEY?.trim());
  const optedIn = env.ENABLE_AI_INSIGHTS?.trim().toLowerCase() === "true";
  const code = env.AI_ACCESS_CODE?.trim() ?? "";
  const isProduction = env.NODE_ENV === "production";

  if (!hasKey || !optedIn) return { enabled: false, requiresCode: false };
  if (isProduction && code === "") return { enabled: false, requiresCode: false };
  return { enabled: true, requiresCode: code !== "" };
}

/** Constant-time comparison so response timing can't reveal the code. */
export function codeMatches(provided: string | null, expected: string | undefined): boolean {
  const want = expected?.trim() ?? "";
  if (want === "") return true; // no code configured (development only; see getAiStatus)
  if (!provided) return false;
  const a = createHash("sha256").update(provided).digest();
  const b = createHash("sha256").update(want).digest();
  return timingSafeEqual(a, b);
}

/** Browsers send Origin on cross-site POSTs. Reject it when it isn't this site. */
export function isSameOrigin(origin: string | null, host: string | null): boolean {
  if (!origin) return true; // same-origin fetches from some clients omit it; the code + rate limit still apply
  try {
    return host !== null && new URL(origin).host === host;
  } catch {
    return false;
  }
}

// ---------- rate limiting ----------

export interface RateLimitResult {
  ok: boolean;
  retryAfterSeconds: number;
}

/**
 * Fixed-window limiter kept in memory: `perKey` requests per `windowMs` for each caller,
 * plus a `globalCap` per 24 hours across everyone.
 *
 * Honest limitation: on serverless hosts (Vercel) each warm instance has its own memory,
 * so this is a speed bump, not a hard guarantee. The access code is the real protection.
 */
export function createRateLimiter(options: {
  perKey: number;
  windowMs: number;
  globalCap: number;
  now?: () => number;
}) {
  const now = options.now ?? Date.now;
  const hits = new Map<string, { count: number; resetAt: number }>();
  let global = { count: 0, resetAt: 0 };
  const DAY = 86_400_000;

  return function check(key: string): RateLimitResult {
    const t = now();

    if (t >= global.resetAt) global = { count: 0, resetAt: t + DAY };
    if (global.count >= options.globalCap) {
      return { ok: false, retryAfterSeconds: Math.ceil((global.resetAt - t) / 1000) };
    }

    // Drop expired entries so the map can't grow without bound.
    if (hits.size > 500) {
      for (const [k, v] of hits) if (t >= v.resetAt) hits.delete(k);
    }

    let entry = hits.get(key);
    if (!entry || t >= entry.resetAt) {
      entry = { count: 0, resetAt: t + options.windowMs };
      hits.set(key, entry);
    }
    if (entry.count >= options.perKey) {
      return { ok: false, retryAfterSeconds: Math.ceil((entry.resetAt - t) / 1000) };
    }

    entry.count += 1;
    global.count += 1;
    return { ok: true, retryAfterSeconds: 0 };
  };
}
