/** A single social media post with its analytics. */
export interface Post {
  /** Unique id (generated on import if the CSV has none). */
  id: string;
  /** Calendar date as YYYY-MM-DD (no time zone, so it never shifts). */
  date: string;
  /** Normalised platform name, e.g. "Instagram", "LinkedIn", "X". */
  platform: string;
  caption: string;
  /** Optional format, e.g. "Image", "Video", "Carousel". "Post" when unknown. */
  contentType: string;
  likes: number;
  comments: number;
  shares: number;
  reach: number;
  impressions: number;
}

/** Where the currently loaded data came from. */
export type DataSource = "demo" | "imported" | "empty";

/** Aggregated numbers for a set of posts. Every dashboard card reads from this. */
export interface MetricsSummary {
  totalPosts: number;
  totalLikes: number;
  totalComments: number;
  totalShares: number;
  totalReach: number;
  totalImpressions: number;
  /** likes + comments + shares */
  totalInteractions: number;
  /** Mean of per-post engagement rates, over posts with reach > 0. Percentage. */
  avgEngagementRate: number;
  /** Posts that were excluded from the average because their reach is 0. */
  zeroReachPosts: number;
}

export type MetricKey = "engagementRate" | "reach" | "interactions";

export interface TrendPoint {
  /** Bucket start date, YYYY-MM-DD. */
  date: string;
  /** Human label for the x-axis. */
  label: string;
  posts: number;
  engagementRate: number;
  reach: number;
  interactions: number;
}

export interface PlatformStat {
  platform: string;
  posts: number;
  engagementRate: number;
  reach: number;
  interactions: number;
}

export interface PostFilters {
  /** Inclusive start date YYYY-MM-DD, or "" for no lower bound. */
  from: string;
  /** Inclusive end date YYYY-MM-DD, or "" for no upper bound. */
  to: string;
  /** Platform name, or "all". */
  platform: string;
}

export interface RowIssue {
  /** 1-based row number as it appears in the file (header is row 1). */
  row: number;
  message: string;
}

export interface CsvParseResult {
  posts: Post[];
  /** Rows that were skipped. */
  errors: RowIssue[];
  /** Rows that were imported but had something worth knowing. */
  warnings: RowIssue[];
  totalRows: number;
  /** Header names found in the file that this app does not use. */
  ignoredColumns: string[];
  /** File-level problem (missing columns, empty file, ...). When set, nothing is importable. */
  fatalError: string | null;
}
