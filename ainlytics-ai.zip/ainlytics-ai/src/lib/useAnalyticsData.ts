"use client";

import { useSyncExternalStore } from "react";
import {
  clearAll,
  getServerSnapshot,
  getSnapshot,
  importPosts,
  resetDemo,
  subscribe,
} from "./store";

/** The one hook every page uses to read and change the dataset. */
export function useAnalyticsData() {
  const state = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  return {
    ...state,
    isLoading: state.status === "loading",
    importPosts,
    resetDemo,
    clearAll,
  };
}
