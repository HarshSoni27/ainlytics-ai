import { addDays, dayOfWeek, daysBetween } from "./metrics";
import type { Post } from "./types";

/**
 * Demo data for a fictional coffee brand ("Brewline Coffee Co.").
 *
 * It is generated with a SEEDED random number generator, so every launch and every
 * "Reset demo data" produces exactly the same ~115 posts. The numbers have realistic
 * structure (platform baselines, content-type and weekday effects, slow growth, a few
 * viral posts and flops) so charts and insights have something real to show.
 */

export const DEMO_START = "2026-08-24";
export const DEMO_END = "2026-11-20";

/** Small, fast, deterministic PRNG (mulberry32). */
function createRng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface TypeOption {
  type: string;
  weight: number;
  /** Multiplier on the engagement rate. */
  factor: number;
}

interface PlatformConfig {
  name: string;
  postsPerWeek: number;
  reach: [number, number];
  /** Baseline engagement rate, percent. */
  baseRate: number;
  types: TypeOption[];
  /** Share of interactions that are comments / shares (the rest are likes). */
  commentShare: number;
  shareShare: number;
  hashtagFactor: number;
  bestDays: number[]; // 0 = Sunday
  weakDays: number[];
}

const PLATFORMS: PlatformConfig[] = [
  {
    name: "Instagram",
    postsPerWeek: 2.4,
    reach: [4500, 13000],
    baseRate: 5.4,
    types: [
      { type: "Image", weight: 0.4, factor: 1.0 },
      { type: "Carousel", weight: 0.3, factor: 1.25 },
      { type: "Reel", weight: 0.3, factor: 1.45 },
    ],
    commentShare: 0.08,
    shareShare: 0.06,
    hashtagFactor: 1.08,
    bestDays: [3, 5],
    weakDays: [0, 1],
  },
  {
    name: "TikTok",
    postsPerWeek: 2,
    reach: [9000, 38000],
    baseRate: 7.2,
    types: [{ type: "Video", weight: 1, factor: 1.0 }],
    commentShare: 0.07,
    shareShare: 0.11,
    hashtagFactor: 1.1,
    bestDays: [4, 6],
    weakDays: [1, 2],
  },
  {
    name: "LinkedIn",
    postsPerWeek: 1.6,
    reach: [2200, 7000],
    baseRate: 3.9,
    types: [
      { type: "Text", weight: 0.35, factor: 0.9 },
      { type: "Image", weight: 0.3, factor: 1.0 },
      { type: "Carousel", weight: 0.35, factor: 1.3 },
    ],
    commentShare: 0.14,
    shareShare: 0.12,
    hashtagFactor: 0.94,
    bestDays: [2, 3],
    weakDays: [0, 6],
  },
  {
    name: "Facebook",
    postsPerWeek: 1.1,
    reach: [2800, 8500],
    baseRate: 2.3,
    types: [
      { type: "Image", weight: 0.45, factor: 1.0 },
      { type: "Video", weight: 0.35, factor: 1.2 },
      { type: "Text", weight: 0.2, factor: 0.8 },
    ],
    commentShare: 0.1,
    shareShare: 0.1,
    hashtagFactor: 0.95,
    bestDays: [3, 5],
    weakDays: [1],
  },
  {
    name: "X",
    postsPerWeek: 2,
    reach: [1800, 9500],
    baseRate: 1.7,
    types: [
      { type: "Text", weight: 0.6, factor: 1.0 },
      { type: "Image", weight: 0.4, factor: 1.15 },
    ],
    commentShare: 0.1,
    shareShare: 0.2,
    hashtagFactor: 0.9,
    bestDays: [2, 4],
    weakDays: [0, 6],
  },
];

const TOPICS = [
  "our new Ethiopian Yirgacheffe roast",
  "cold brew season",
  "the barista behind your morning cup",
  "how we source beans directly from farmers",
  "a 5-minute pour-over guide",
  "oat milk vs whole milk lattes",
  "our loyalty program",
  "a day inside the roastery",
  "our new compostable packaging",
  "weekend brunch specials",
  "latte art for beginners",
  "the Honey Cortado",
  "office coffee subscriptions",
  "World Coffee Day",
  "a pumpkin-spice alternative",
  "grind size explained",
  "meet our roasting team",
  "student discounts",
  "holiday gift boxes",
  "decaf that doesn't taste like a compromise",
  "espresso at home on a budget",
  "our Colombian single origin",
  "the story behind our logo",
  "choosing the right brewing method",
];

interface CaptionTemplate {
  build: (topic: string) => string;
  question: boolean;
  hashtags: boolean;
}

const TEMPLATES: CaptionTemplate[] = [
  { build: (t) => `Behind the scenes: ${t}. Swipe to see how it's made. #coffee #behindthescenes`, question: false, hashtags: true },
  { build: (t) => `New drop alert ☕ ${t} is here. Tell us what you think!`, question: false, hashtags: false },
  { build: (t) => `Quick tip: everything you need to know about ${t} in under a minute. #coffeetips`, question: false, hashtags: true },
  { build: (t) => `Poll time! What's your take on ${t}? Vote in the comments 👇`, question: true, hashtags: false },
  { build: (t) => `Why we do ${t} the way we do. A short story from the team.`, question: false, hashtags: false },
  { build: (t) => `We asked our community about ${t}. Here's what they said.`, question: false, hashtags: false },
  { build: (t) => `Save this for later: a simple guide to ${t}. #coffeelover #brew`, question: false, hashtags: true },
  { build: (t) => `Limited time: ${t}. Offer ends Sunday.`, question: false, hashtags: false },
  { build: (t) => `What did we learn from ${t}? Here are three honest lessons.`, question: true, hashtags: false },
  { build: (t) => `Meet the team: the story behind ${t}. #smallbusiness #coffee`, question: false, hashtags: true },
  { build: (t) => `Do you know the secret to ${t}? Hint: it starts at the farm. #specialtycoffee`, question: true, hashtags: true },
  { build: (t) => `Hot take: ${t} is underrated. Agree or disagree?`, question: true, hashtags: false },
];

function pickWeighted<T extends { weight: number }>(
  items: T[],
  rand: () => number,
): T {
  const total = items.reduce((s, i) => s + i.weight, 0);
  let r = rand() * total;
  for (const item of items) {
    r -= item.weight;
    if (r <= 0) return item;
  }
  return items[items.length - 1];
}

export function generateDemoPosts(): Post[] {
  const rand = createRng(20261120);
  const totalDays = daysBetween(DEMO_START, DEMO_END);
  const usedCaptions = new Set<string>();
  const drafts: Omit<Post, "id">[] = [];

  for (let offset = 0; offset <= totalDays; offset++) {
    const date = addDays(DEMO_START, offset);
    const dow = dayOfWeek(date);
    const weekIndex = Math.floor(offset / 7);
    // Slow growth over the period (~+15% over 12 weeks).
    const trend = 1 + 0.012 * weekIndex;

    for (const cfg of PLATFORMS) {
      if (rand() >= cfg.postsPerWeek / 7) continue;

      const typeOpt = pickWeighted(
        cfg.types.map((t) => ({ ...t })),
        rand,
      );
      const template = TEMPLATES[Math.floor(rand() * TEMPLATES.length)];
      const topic = TOPICS[Math.floor(rand() * TOPICS.length)];
      let caption = template.build(topic);
      if (usedCaptions.has(caption)) {
        caption = `${caption} (Part ${usedCaptions.size % 7 + 2})`;
      }
      usedCaptions.add(caption);

      const dayFactor = cfg.bestDays.includes(dow)
        ? 1.18
        : cfg.weakDays.includes(dow)
          ? 0.82
          : 1;
      const captionFactor =
        (template.question ? 1.12 : 1) *
        (template.hashtags ? cfg.hashtagFactor : 1);

      // ~4% viral, ~4% flop
      const roll = rand();
      const special = roll < 0.04 ? 2.3 : roll > 0.96 ? 0.45 : 1;

      const [lo, hi] = cfg.reach;
      const reach = Math.round(lo + (hi - lo) * Math.pow(rand(), 1.5));
      const rate =
        cfg.baseRate *
        typeOpt.factor *
        dayFactor *
        trend *
        captionFactor *
        special *
        (0.8 + 0.4 * rand());

      const interactions = Math.max(1, Math.round((reach * rate) / 100));
      const comments = Math.round(
        interactions * cfg.commentShare * (0.8 + 0.4 * rand()),
      );
      const shares = Math.round(
        interactions * cfg.shareShare * (0.8 + 0.4 * rand()),
      );
      const likes = Math.max(0, interactions - comments - shares);
      const impressions = Math.round(reach * (1.12 + 0.5 * rand()));

      drafts.push({
        date,
        platform: cfg.name,
        caption,
        contentType: typeOpt.type,
        likes,
        comments,
        shares,
        reach,
        impressions,
      });
    }
  }

  drafts.sort(
    (a, b) =>
      a.date.localeCompare(b.date) || a.platform.localeCompare(b.platform),
  );

  return drafts.map((d, i) => ({
    ...d,
    id: `demo-${String(i + 1).padStart(3, "0")}`,
  }));
}
