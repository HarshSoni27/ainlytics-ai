import Papa from "papaparse";
import type { CsvParseResult, Post, RowIssue } from "./types";

export const MAX_FILE_BYTES = 5 * 1024 * 1024; // 5 MB
export const MAX_ROWS = 5000;

export const REQUIRED_COLUMNS = [
  "date",
  "platform",
  "caption",
  "likes",
  "comments",
  "shares",
  "reach",
  "impressions",
] as const;

export const OPTIONAL_COLUMNS = ["content_type"] as const;

type Column = (typeof REQUIRED_COLUMNS)[number] | (typeof OPTIONAL_COLUMNS)[number];

/** Alternative header names we accept, mapped to our canonical column. */
const HEADER_ALIASES: Record<string, Column> = {
  post_date: "date",
  published_at: "date",
  posted_at: "date",
  network: "platform",
  channel: "platform",
  text: "caption",
  content: "caption",
  post_text: "caption",
  like_count: "likes",
  comment_count: "comments",
  share_count: "shares",
  reposts: "shares",
  post_type: "content_type",
  format: "content_type",
  type: "content_type",
};

const KNOWN_PLATFORMS: Record<string, string> = {
  instagram: "Instagram",
  ig: "Instagram",
  insta: "Instagram",
  facebook: "Facebook",
  fb: "Facebook",
  linkedin: "LinkedIn",
  x: "X",
  twitter: "X",
  "x (twitter)": "X",
  "twitter/x": "X",
  tiktok: "TikTok",
  "tik tok": "TikTok",
  youtube: "YouTube",
  yt: "YouTube",
  threads: "Threads",
  pinterest: "Pinterest",
};

const MAX_CAPTION_LENGTH = 2000;
const MAX_COUNT = 1_000_000_000_000;

// ---------- helpers ----------

export function normalizeHeader(raw: string): string {
  const cleaned = raw
    .replace(/^﻿/, "")
    .trim()
    .toLowerCase()
    .replace(/[\s\-]+/g, "_")
    .replace(/[^a-z0-9_]/g, "");
  return HEADER_ALIASES[cleaned] ?? cleaned;
}

export function normalizePlatform(raw: string): string {
  const trimmed = raw.trim().replace(/\s+/g, " ");
  const known = KNOWN_PLATFORMS[trimmed.toLowerCase()];
  if (known) return known;
  // Unknown platform: keep what they wrote, but tidy the capitalisation of the first letter.
  return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
}

function normalizeContentType(raw: string | undefined): string {
  const trimmed = (raw ?? "").trim();
  if (!trimmed) return "Post";
  return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
}

/**
 * Accepts YYYY-MM-DD (optionally followed by a time) or YYYY/MM/DD.
 * Returns a validated YYYY-MM-DD string, or null.
 */
export function parseDate(raw: string): string | null {
  const m = raw
    .trim()
    .match(
      /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[T ]\d{1,2}:\d{2}(?::\d{2}(?:\.\d+)?)?\s*(?:Z|[+-]\d{2}:?\d{2})?)?$/,
    );
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  if (y < 2000 || y > 2100) return null;
  const ms = Date.UTC(y, mo - 1, d);
  const check = new Date(ms);
  // Rejects impossible dates such as 2026-02-31.
  if (
    check.getUTCFullYear() !== y ||
    check.getUTCMonth() !== mo - 1 ||
    check.getUTCDate() !== d
  ) {
    return null;
  }
  return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

type CountResult =
  | { kind: "missing" }
  | { kind: "ok"; value: number }
  | { kind: "error"; message: string };

/** Parses a non-negative whole number. Empty => missing. Accepts "1,234" and "120.0". */
export function parseCount(raw: string | undefined, column: string): CountResult {
  if (raw === undefined || raw === null) return { kind: "missing" };
  let s = String(raw).trim();
  if (s === "") return { kind: "missing" };

  if (/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, "");

  if (!/^-?\d+(\.\d+)?$/.test(s)) {
    return {
      kind: "error",
      message: `"${column}" must be a whole number, got "${truncateForMessage(raw)}"`,
    };
  }
  const n = Number(s);
  if (n < 0) {
    return { kind: "error", message: `"${column}" cannot be negative (got ${s})` };
  }
  if (!Number.isInteger(n)) {
    return {
      kind: "error",
      message: `"${column}" must be a whole number, got ${s}`,
    };
  }
  if (n > MAX_COUNT) {
    return { kind: "error", message: `"${column}" is unrealistically large (${s})` };
  }
  return { kind: "ok", value: n };
}

function truncateForMessage(s: string): string {
  const t = String(s).trim();
  return t.length > 30 ? `${t.slice(0, 29)}…` : t;
}

function emptyResult(fatalError: string | null, totalRows = 0): CsvParseResult {
  return {
    posts: [],
    errors: [],
    warnings: [],
    totalRows,
    ignoredColumns: [],
    fatalError,
  };
}

// ---------- main parser ----------

export function parseCsvText(
  text: string,
  options: { idPrefix?: string } = {},
): CsvParseResult {
  if (!text || !text.trim()) {
    return emptyResult("The file is empty.");
  }

  const parsed = Papa.parse<Record<string, string>>(text, {
    header: true,
    skipEmptyLines: false,
    transformHeader: normalizeHeader,
  });

  const headers = (parsed.meta.fields ?? []).filter((h) => h !== "");
  if (headers.length === 0) {
    return emptyResult("Could not find a header row. The first row must contain column names.");
  }

  const missing = REQUIRED_COLUMNS.filter((c) => !headers.includes(c));
  if (missing.length > 0) {
    return {
      ...emptyResult(
        `Missing required column${missing.length > 1 ? "s" : ""}: ${missing.join(", ")}. ` +
          `Found: ${headers.join(", ")}. Required: ${REQUIRED_COLUMNS.join(", ")}.`,
      ),
      ignoredColumns: headers,
    };
  }

  const known = new Set<string>([...REQUIRED_COLUMNS, ...OPTIONAL_COLUMNS]);
  const ignoredColumns = headers.filter((h) => !known.has(h));

  // Row-length problems reported by Papa, keyed by data-row index.
  const mismatch = new Map<number, string>();
  for (const err of parsed.errors) {
    if (err.type === "FieldMismatch" && typeof err.row === "number") {
      mismatch.set(
        err.row,
        err.code === "TooManyFields"
          ? "has more values than the header has columns (extra values ignored)"
          : "has fewer values than the header has columns (missing values treated as empty)",
      );
    }
  }
  const delimiterProblem = parsed.errors.find(
    (e) => e.type === "Delimiter" || e.type === "Quotes",
  );

  const rows = parsed.data;
  const nonBlank = rows.filter((r) => Object.values(r).some((v) => String(v ?? "").trim() !== ""));
  if (nonBlank.length === 0) {
    return emptyResult("The file has a header row but no data rows.");
  }
  if (nonBlank.length > MAX_ROWS) {
    return emptyResult(
      `The file has ${nonBlank.length.toLocaleString("en-US")} rows, but this MVP supports at most ${MAX_ROWS.toLocaleString("en-US")}. Split the file and import it in parts.`,
      nonBlank.length,
    );
  }

  const prefix =
    options.idPrefix ??
    `imp-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

  const posts: Post[] = [];
  const errors: RowIssue[] = [];
  const warnings: RowIssue[] = [];

  rows.forEach((row, index) => {
    const isBlank = !Object.values(row).some((v) => String(v ?? "").trim() !== "");
    if (isBlank) return; // blank lines and the trailing newline are not errors

    const rowNumber = index + 2; // row 1 is the header
    const rowErrors: string[] = [];
    const rowWarnings: string[] = [];

    const shapeNote = mismatch.get(index);
    if (shapeNote) rowWarnings.push(`Row ${shapeNote}`);

    // date
    const dateRaw = (row.date ?? "").trim();
    let date = "";
    if (dateRaw === "") {
      rowErrors.push(`"date" is empty`);
    } else {
      const parsedDate = parseDate(dateRaw);
      if (!parsedDate) {
        rowErrors.push(
          `"date" must look like 2026-11-20 (YYYY-MM-DD), got "${truncateForMessage(dateRaw)}"`,
        );
      } else {
        date = parsedDate;
      }
    }

    // platform
    const platformRaw = (row.platform ?? "").trim();
    if (platformRaw === "") rowErrors.push(`"platform" is empty`);
    const platform = platformRaw ? normalizePlatform(platformRaw) : "";

    // caption
    let caption = (row.caption ?? "").trim();
    if (caption === "") {
      caption = "(no caption)";
      rowWarnings.push(`"caption" is empty`);
    } else if (caption.length > MAX_CAPTION_LENGTH) {
      caption = caption.slice(0, MAX_CAPTION_LENGTH);
      rowWarnings.push(`"caption" was longer than ${MAX_CAPTION_LENGTH} characters and was shortened`);
    }

    // numeric columns
    const numbers: Record<string, number> = {};
    for (const col of ["likes", "comments", "shares", "reach", "impressions"] as const) {
      const result = parseCount(row[col], col);
      if (result.kind === "error") {
        rowErrors.push(result.message);
      } else if (result.kind === "missing") {
        numbers[col] = 0;
        rowWarnings.push(`"${col}" is empty, treated as 0`);
      } else {
        numbers[col] = result.value;
      }
    }

    if (rowErrors.length > 0) {
      errors.push({ row: rowNumber, message: rowErrors.join("; ") });
      return;
    }

    const { likes, comments, shares, reach, impressions } = numbers;
    const interactions = likes + comments + shares;

    if (reach === 0) {
      rowWarnings.push(
        interactions > 0
          ? "reach is 0 but there are interactions; engagement rate can't be calculated and this post is left out of averages"
          : "reach is 0; engagement rate can't be calculated and this post is left out of averages",
      );
    } else if (interactions > reach) {
      rowWarnings.push(
        `interactions (${interactions}) exceed reach (${reach}), so the engagement rate is above 100%; please double-check`,
      );
    }
    if (reach > 0 && impressions > 0 && impressions < reach) {
      rowWarnings.push("impressions are lower than reach (usually impressions ≥ reach)");
    }

    if (rowWarnings.length > 0) {
      warnings.push({ row: rowNumber, message: rowWarnings.join("; ") });
    }

    posts.push({
      id: `${prefix}-${rowNumber}`,
      date,
      platform,
      caption,
      contentType: normalizeContentType(row.content_type),
      likes,
      comments,
      shares,
      reach,
      impressions,
    });
  });

  const result: CsvParseResult = {
    posts,
    errors,
    warnings,
    totalRows: nonBlank.length,
    ignoredColumns,
    fatalError: null,
  };

  if (posts.length === 0 && delimiterProblem) {
    result.fatalError = `Could not read the file as CSV (${delimiterProblem.message}).`;
  }
  return result;
}

/** Reads a File from an <input> or drop zone and parses it. Never throws. */
export async function parseCsvFile(file: File): Promise<CsvParseResult> {
  const looksLikeCsv =
    /\.csv$/i.test(file.name) ||
    file.type === "text/csv" ||
    file.type === "application/vnd.ms-excel" ||
    file.type === "text/plain";
  if (!looksLikeCsv) {
    return emptyResult(
      `"${file.name}" doesn't look like a CSV file. Please choose a .csv file (in Excel: File → Save As → CSV).`,
    );
  }
  if (file.size === 0) return emptyResult("The file is empty.");
  if (file.size > MAX_FILE_BYTES) {
    return emptyResult(
      `The file is ${(file.size / 1024 / 1024).toFixed(1)} MB. The limit for this MVP is ${MAX_FILE_BYTES / 1024 / 1024} MB.`,
    );
  }
  try {
    const text = await file.text();
    return parseCsvText(text);
  } catch {
    return emptyResult("The file could not be read. Try selecting it again.");
  }
}

// ---------- merging ----------

/** Two posts are considered the same if platform, date and caption match. */
export function postKey(p: Pick<Post, "date" | "platform" | "caption">): string {
  return `${p.date}|${p.platform.toLowerCase()}|${p.caption.trim().toLowerCase()}`;
}

export function mergePosts(
  existing: Post[],
  incoming: Post[],
): { merged: Post[]; added: number; duplicates: number } {
  const seen = new Set(existing.map(postKey));
  const additions: Post[] = [];
  let duplicates = 0;
  for (const p of incoming) {
    const key = postKey(p);
    if (seen.has(key)) {
      duplicates += 1;
      continue;
    }
    seen.add(key);
    additions.push(p);
  }
  return {
    merged: [...existing, ...additions],
    added: additions.length,
    duplicates,
  };
}
