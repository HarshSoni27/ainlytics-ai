"use client";

import { useEffect, useMemo, useRef } from "react";
import { formatDate, formatInt, formatPercent } from "@/lib/format";
import { averageEngagementRate, engagementRate, interactionsOf } from "@/lib/metrics";
import type { Post } from "@/lib/types";
import { platformColor } from "./charts/chartTheme";
import { CloseIcon } from "./icons";
import { Alert, Badge } from "./ui";

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/[0.07] bg-navy-900 p-3">
      <dt className="text-xs text-slate-400">{label}</dt>
      <dd className="mt-1 text-lg font-semibold tabular-nums text-white">{value}</dd>
    </div>
  );
}

export function PostDetailPanel({
  post,
  allPosts,
  onClose,
}: {
  post: Post | null;
  /** The whole dataset, used for the post's rank and the average to compare against. */
  allPosts: Post[];
  onClose: () => void;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!post) return;
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [post, onClose]);

  const context = useMemo(() => {
    if (!post) return null;
    const rated = allPosts.filter((p) => p.reach > 0);
    const rate = engagementRate(post);
    const rank = post.reach > 0 ? rated.filter((p) => engagementRate(p) > rate).length + 1 : null;
    return { rate, rank, ratedCount: rated.length, avg: averageEngagementRate(allPosts) };
  }, [post, allPosts]);

  if (!post || !context) return null;

  const interactions = interactionsOf(post);
  const vsAvg = context.avg > 0 && post.reach > 0 ? context.rate / context.avg : null;

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Post details">
      <div className="absolute inset-0 bg-navy-950/75" onClick={onClose} aria-hidden="true" />
      <aside className="absolute inset-y-0 right-0 flex w-full max-w-lg flex-col overflow-y-auto border-l border-white/10 bg-navy-850 shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-white/[0.07] p-5">
          <div>
            <p className="flex items-center gap-2 text-sm text-slate-300">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: platformColor(post.platform) }} />
              {post.platform}
              <span className="text-slate-600" aria-hidden="true">/</span>
              {formatDate(post.date)}
            </p>
            <div className="mt-2">
              <Badge>{post.contentType}</Badge>
            </div>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Close post details"
            className="rounded-lg p-2 text-slate-400 hover:bg-white/5 hover:text-white"
          >
            <CloseIcon />
          </button>
        </div>

        <div className="space-y-6 p-5">
          <div>
            <h2 className="mb-2 text-sm font-medium text-slate-400">Caption</h2>
            <p className="whitespace-pre-wrap break-words text-[0.95rem] leading-relaxed text-slate-100">
              {post.caption}
            </p>
          </div>

          <div className="rounded-xl border border-accent-500/25 bg-accent-500/[0.07] p-4">
            <p className="text-sm text-slate-300">Engagement rate</p>
            <p className="mt-1 text-4xl font-semibold tabular-nums text-white">
              {post.reach > 0 ? formatPercent(context.rate) : "n/a"}
            </p>
            {post.reach > 0 ? (
              <>
                <p className="mt-2 text-xs leading-relaxed text-slate-400">
                  ({formatInt(post.likes)} likes + {formatInt(post.comments)} comments + {formatInt(post.shares)} shares) ÷{" "}
                  {formatInt(post.reach)} reach × 100
                </p>
                <p className="mt-2 text-sm text-slate-200">
                  {context.rank !== null && (
                    <>
                      Ranked <strong>#{context.rank}</strong> of {context.ratedCount} posts
                      {vsAvg !== null && (
                        <>
                          , {vsAvg >= 1 ? `${vsAvg.toFixed(1)}× the` : `${(vsAvg * 100).toFixed(0)}% of the`} average of{" "}
                          {formatPercent(context.avg)}
                        </>
                      )}
                      .
                    </>
                  )}
                </p>
              </>
            ) : (
              <p className="mt-2 text-sm text-slate-300">
                This post has no reach, so its engagement rate can&apos;t be calculated.
              </p>
            )}
          </div>

          <dl className="grid grid-cols-2 gap-3">
            <Stat label="Likes" value={formatInt(post.likes)} />
            <Stat label="Comments" value={formatInt(post.comments)} />
            <Stat label="Shares" value={formatInt(post.shares)} />
            <Stat label="Total interactions" value={formatInt(interactions)} />
            <Stat label="Reach" value={formatInt(post.reach)} />
            <Stat label="Impressions" value={formatInt(post.impressions)} />
          </dl>

          {post.reach === 0 && (
            <Alert tone="warning" title="Zero reach">
              Posts with zero reach are left out of average engagement calculations.
            </Alert>
          )}
        </div>
      </aside>
    </div>
  );
}
