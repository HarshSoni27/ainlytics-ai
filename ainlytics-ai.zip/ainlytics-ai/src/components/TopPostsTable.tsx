"use client";

import { useMemo } from "react";
import { formatDate, formatInt, formatPercent, truncate } from "@/lib/format";
import { engagementRate, interactionsOf } from "@/lib/metrics";
import type { Post } from "@/lib/types";
import { platformColor } from "./charts/chartTheme";
import { ButtonLink, Card, CardHeader } from "./ui";

export function TopPostsTable({
  posts,
  onSelect,
  limit = 8,
}: {
  posts: Post[];
  onSelect: (post: Post) => void;
  limit?: number;
}) {
  const top = useMemo(
    () =>
      posts
        .filter((p) => p.reach > 0)
        .map((post) => ({ post, rate: engagementRate(post) }))
        .sort((a, b) => b.rate - a.rate)
        .slice(0, limit),
    [posts, limit],
  );

  return (
    <Card>
      <CardHeader
        title="Top-performing posts"
        description="Ranked by engagement rate. Posts with no reach are left out."
        actions={
          <ButtonLink href="/posts" variant="secondary">
            View all posts
          </ButtonLink>
        }
      />

      {top.length === 0 ? (
        <p className="py-10 text-center text-sm text-slate-400">No posts with reach in this selection.</p>
      ) : (
        <div className="-mx-1 overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <caption className="sr-only">Top-performing posts by engagement rate</caption>
            <thead className="text-left text-xs text-slate-400">
              <tr className="border-b border-white/[0.07]">
                <th scope="col" className="w-8 px-3 py-2.5 font-medium">#</th>
                <th scope="col" className="px-3 py-2.5 font-medium">Post</th>
                <th scope="col" className="px-3 py-2.5 font-medium">Platform</th>
                <th scope="col" className="px-3 py-2.5 text-right font-medium">Reach</th>
                <th scope="col" className="px-3 py-2.5 text-right font-medium">Interactions</th>
                <th scope="col" className="px-3 py-2.5 text-right font-medium">Engagement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05] tabular-nums">
              {top.map(({ post, rate }, i) => (
                <tr
                  key={post.id}
                  onClick={() => onSelect(post)}
                  className="cursor-pointer transition-colors hover:bg-white/[0.03]"
                >
                  <td className="px-3 py-3 text-slate-500">{i + 1}</td>
                  <td className="max-w-md px-3 py-3">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelect(post);
                      }}
                      className="block w-full text-left"
                    >
                      <span className="block text-slate-100 hover:text-accent-300">
                        {truncate(post.caption, 80)}
                      </span>
                      <span className="mt-0.5 block text-xs text-slate-500">
                        {formatDate(post.date)} · {post.contentType}
                      </span>
                    </button>
                  </td>
                  <td className="px-3 py-3 text-slate-300">
                    <span className="inline-flex items-center gap-2">
                      <span className="h-2 w-2 rounded-sm" style={{ background: platformColor(post.platform) }} />
                      {post.platform}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-right text-slate-300">{formatInt(post.reach)}</td>
                  <td className="px-3 py-3 text-right text-slate-300">{formatInt(interactionsOf(post))}</td>
                  <td className="px-3 py-3 text-right font-semibold text-white">{formatPercent(rate)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
