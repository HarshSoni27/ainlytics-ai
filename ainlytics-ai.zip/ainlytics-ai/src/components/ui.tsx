"use client";

import Link from "next/link";
import {
  useEffect,
  useId,
  useRef,
  type ComponentProps,
  type ReactNode,
} from "react";
import { AlertIcon, CheckIcon, CloseIcon } from "./icons";

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

// ---------- Card ----------

export function Card({
  children,
  className,
  as: Tag = "section",
}: {
  children: ReactNode;
  className?: string;
  as?: "section" | "div" | "article";
}) {
  return (
    <Tag
      className={cx(
        "rounded-xl border border-white/[0.07] bg-navy-850 p-5 sm:p-6",
        className,
      )}
    >
      {children}
    </Tag>
  );
}

export function CardHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
      <div className="min-w-0">
        <h2 className="text-base font-semibold text-slate-100">{title}</h2>
        {description && (
          <p className="mt-1 text-sm text-slate-400">{description}</p>
        )}
      </div>
      {actions}
    </div>
  );
}

// ---------- Buttons ----------

type Variant = "primary" | "secondary" | "ghost" | "danger";

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-accent-600 text-white hover:bg-accent-500 disabled:hover:bg-accent-600",
  secondary:
    "border border-white/10 bg-navy-800 text-slate-200 hover:bg-navy-700 disabled:hover:bg-navy-800",
  ghost: "text-slate-300 hover:bg-white/5 hover:text-white",
  danger:
    "bg-red-500/90 text-white hover:bg-red-500 disabled:hover:bg-red-500/90",
};

const BUTTON_BASE =
  "inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50";

export function Button({
  variant = "secondary",
  className,
  ...props
}: ComponentProps<"button"> & { variant?: Variant }) {
  return (
    <button
      type="button"
      className={cx(BUTTON_BASE, VARIANTS[variant], className)}
      {...props}
    />
  );
}

export function ButtonLink({
  href,
  variant = "secondary",
  className,
  children,
  download,
}: {
  href: string;
  variant?: Variant;
  className?: string;
  children: ReactNode;
  download?: boolean;
}) {
  const classes = cx(BUTTON_BASE, VARIANTS[variant], className);
  // A plain <a> for downloads: next/link would try to client-navigate to a file.
  if (download) {
    return (
      <a href={href} download className={classes}>
        {children}
      </a>
    );
  }
  return (
    <Link href={href} className={classes}>
      {children}
    </Link>
  );
}

// ---------- Form controls ----------

export const CONTROL_CLASS =
  "h-10 rounded-lg border border-white/10 bg-navy-900 px-3 text-sm text-slate-200 placeholder:text-slate-500 hover:border-white/20 focus:border-accent-500";

export function Field({
  label,
  htmlFor,
  children,
  className,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cx("flex flex-col gap-1.5", className)}>
      <label htmlFor={htmlFor} className="text-xs font-medium text-slate-400">
        {label}
      </label>
      {children}
    </div>
  );
}

// ---------- Badges & status ----------

export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "accent" | "good" | "warn" | "bad";
}) {
  const tones = {
    neutral: "bg-white/5 text-slate-300 border-white/10",
    accent: "bg-accent-500/10 text-accent-300 border-accent-500/25",
    good: "bg-emerald-500/10 text-emerald-300 border-emerald-500/25",
    warn: "bg-amber-500/10 text-amber-300 border-amber-500/25",
    bad: "bg-red-500/10 text-red-300 border-red-500/25",
  } as const;
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        tones[tone],
      )}
    >
      {children}
    </span>
  );
}

export function Alert({
  tone = "error",
  title,
  children,
  onDismiss,
}: {
  tone?: "error" | "warning" | "success" | "info";
  title?: string;
  children?: ReactNode;
  onDismiss?: () => void;
}) {
  const tones = {
    error: "border-red-500/30 bg-red-500/[0.08] text-red-200",
    warning: "border-amber-500/30 bg-amber-500/[0.08] text-amber-200",
    success: "border-emerald-500/30 bg-emerald-500/[0.08] text-emerald-200",
    info: "border-accent-500/30 bg-accent-500/[0.08] text-accent-300",
  } as const;
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={cx("flex gap-3 rounded-lg border p-4 text-sm", tones[tone])}
    >
      <span className="mt-0.5 shrink-0">
        {tone === "success" ? (
          <CheckIcon width={18} height={18} />
        ) : (
          <AlertIcon width={18} height={18} />
        )}
      </span>
      <div className="min-w-0 flex-1">
        {title && <p className="font-semibold">{title}</p>}
        {children && (
          <div className={cx("text-[0.8125rem] leading-relaxed", title && "mt-1 opacity-90")}>
            {children}
          </div>
        )}
      </div>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss message"
          className="shrink-0 self-start rounded p-1 opacity-70 hover:opacity-100"
        >
          <CloseIcon width={16} height={16} />
        </button>
      )}
    </div>
  );
}

export function Spinner({ label = "Loading" }: { label?: string }) {
  return (
    <span role="status" className="inline-flex items-center gap-2 text-sm text-slate-400">
      <svg
        className="h-4 w-4 animate-spin text-accent-400"
        viewBox="0 0 24 24"
        fill="none"
        aria-hidden="true"
      >
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3" />
        <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      </svg>
      {label}
    </span>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      aria-hidden="true"
      className={cx("animate-pulse rounded-lg bg-white/[0.05]", className)}
    />
  );
}

export function EmptyState({
  title,
  children,
  actions,
}: {
  title: string;
  children?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center rounded-xl border border-dashed border-white/10 px-6 py-14 text-center">
      <h2 className="text-lg font-semibold text-slate-100">{title}</h2>
      {children && (
        <p className="mt-2 max-w-md text-sm leading-relaxed text-slate-400">{children}</p>
      )}
      {actions && <div className="mt-6 flex flex-wrap justify-center gap-3">{actions}</div>}
    </div>
  );
}

// ---------- Segmented control (used for chart metric / view toggles) ----------

export function Segmented<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div
      role="group"
      aria-label={label}
      className="inline-flex rounded-lg border border-white/10 bg-navy-900 p-0.5"
    >
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          aria-pressed={o.value === value}
          onClick={() => onChange(o.value)}
          className={cx(
            "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
            o.value === value
              ? "bg-accent-600/90 text-white"
              : "text-slate-400 hover:text-slate-200",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

// ---------- Modal (used for confirmations) ----------

export function ConfirmDialog({
  open,
  title,
  children,
  confirmLabel,
  cancelLabel = "Cancel",
  destructive = false,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  children: ReactNode;
  confirmLabel: string;
  cancelLabel?: string;
  destructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const titleId = useId();
  const cancelRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    cancelRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCancel();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onCancel]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby={titleId}
    >
      <div
        className="absolute inset-0 bg-navy-950/80 backdrop-blur-sm"
        onClick={onCancel}
        aria-hidden="true"
      />
      <div className="relative w-full max-w-md rounded-xl border border-white/10 bg-navy-800 p-6 shadow-2xl">
        <h2 id={titleId} className="text-lg font-semibold text-slate-50">
          {title}
        </h2>
        <div className="mt-2 text-sm leading-relaxed text-slate-300">{children}</div>
        <div className="mt-6 flex justify-end gap-3">
          <Button ref={cancelRef} variant="secondary" onClick={onCancel}>
            {cancelLabel}
          </Button>
          <Button variant={destructive ? "danger" : "primary"} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}
