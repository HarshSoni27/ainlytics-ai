"use client";

import { useState } from "react";
import { useAnalyticsData } from "@/lib/useAnalyticsData";
import { ButtonLink, Button, EmptyState } from "./ui";

/** Shown on any page when there are no posts at all. */
export function NoDataState() {
  const { resetDemo } = useAnalyticsData();
  const [restored, setRestored] = useState(false);

  return (
    <EmptyState
      title="No data to show yet"
      actions={
        <>
          <ButtonLink href="/upload" variant="primary">
            Upload a CSV
          </ButtonLink>
          <Button
            onClick={() => {
              resetDemo();
              setRestored(true);
            }}
            disabled={restored}
          >
            Load demo data
          </Button>
        </>
      }
    >
      Upload a CSV of your post analytics, or load the demo data to explore the dashboard.
    </EmptyState>
  );
}
