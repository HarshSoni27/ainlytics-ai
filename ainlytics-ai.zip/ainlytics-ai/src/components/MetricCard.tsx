import type { ReactNode } from "react";
import { cx, Skeleton } from "./ui";

export function MetricCard({
  label,
  value,
  hint,
  featured = false,
  className,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  /** The one card that carries the headline number. */
  featured?: boolean;
  className?: string;
}) {
  return (
    <div
      className={cx(
        "rounded-xl border p-5",
        featured
          ? "border-accent-500/30 bg-gradient-to-br from-accent-600/20 via-navy-850 to-navy-850"
          : "border-white/[0.07] bg-navy-850",
        className,
      )}
    >
      <p className="text-sm text-slate-400">{label}</p>
      <p
        className={cx(
          "mt-2 font-semibold tabular-nums tracking-tight text-white",
          featured ? "text-4xl sm:text-5xl" : "text-2xl sm:text-[1.7rem]",
        )}
      >
        {value}
      </p>
      {hint && <p className="mt-2 text-xs leading-relaxed text-slate-500">{hint}</p>}
    </div>
  );
}

export function MetricCardSkeleton({ featured = false, className }: { featured?: boolean; className?: string }) {
  return (
    <div className={cx("rounded-xl border border-white/[0.07] bg-navy-850 p-5", className)}>
      <Skeleton className="h-4 w-24" />
      <Skeleton className={cx("mt-3", featured ? "h-12 w-40" : "h-8 w-28")} />
    </div>
  );
}
