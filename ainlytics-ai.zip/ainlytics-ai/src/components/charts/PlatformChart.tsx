"use client";

import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipContentProps,
} from "recharts";
import type { NameType, ValueType } from "recharts/types/component/DefaultTooltipContent";
import { formatInt } from "@/lib/format";
import { buildPlatformStats } from "@/lib/metrics";
import type { MetricKey, PlatformStat, Post } from "@/lib/types";
import { Card, CardHeader, Segmented } from "../ui";
import {
  CHART,
  formatAxisMetric,
  formatMetric,
  METRIC_LABEL,
  METRIC_OPTIONS,
  platformColor,
} from "./chartTheme";

type View = "chart" | "table";

function PlatformTooltip({
  active,
  payload,
  metric,
}: Partial<TooltipContentProps<ValueType, NameType>> & { metric: MetricKey }) {
  if (!active || !payload || payload.length === 0) return null;
  const stat = payload[0].payload as PlatformStat;
  return (
    <div className="rounded-lg border border-white/10 bg-navy-700 px-3 py-2.5 text-xs shadow-xl">
      <p className="mb-1.5 flex items-center gap-2 text-slate-300">
        <span className="h-2 w-2 rounded-sm" style={{ background: platformColor(stat.platform) }} />
        {stat.platform}
      </p>
      <p className="flex items-baseline gap-2">
        <span className="text-sm font-semibold text-white">{formatMetric(metric, stat[metric])}</span>
        <span className="text-slate-400">{METRIC_LABEL[metric]}</span>
      </p>
      <p className="mt-1 text-slate-500">
        {stat.posts} post{stat.posts === 1 ? "" : "s"}
      </p>
    </div>
  );
}

export function PlatformChart({ posts }: { posts: Post[] }) {
  const [metric, setMetric] = useState<MetricKey>("engagementRate");
  const [view, setView] = useState<View>("chart");

  const data = useMemo(
    () => [...buildPlatformStats(posts)].sort((a, b) => b[metric] - a[metric]),
    [posts, metric],
  );

  // 40px per row keeps bars thin (≤ 24px) with air between them.
  const chartHeight = Math.max(160, data.length * 44 + 32);

  return (
    <Card>
      <CardHeader
        title="Platform performance"
        description={`${METRIC_LABEL[metric]} by platform`}
        actions={
          <div className="flex flex-wrap gap-2">
            <Segmented label="Metric" value={metric} options={METRIC_OPTIONS} onChange={setMetric} />
            <Segmented
              label="View"
              value={view}
              options={[
                { value: "chart", label: "Chart" },
                { value: "table", label: "Table" },
              ]}
              onChange={setView}
            />
          </div>
        }
      />

      {data.length === 0 ? (
        <p className="py-16 text-center text-sm text-slate-400">No posts in this selection.</p>
      ) : view === "chart" ? (
        <div
          role="img"
          aria-label={`${METRIC_LABEL[metric]} by platform. Switch to table view for the values.`}
          style={{ height: chartHeight }}
          className="w-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              layout="vertical"
              margin={{ top: 4, right: 56, bottom: 0, left: 0 }}
              barCategoryGap={12}
            >
              <CartesianGrid stroke={CHART.grid} horizontal={false} />
              <XAxis
                type="number"
                tick={{ fill: CHART.tick, fontSize: 12 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v: number) => formatAxisMetric(metric, v)}
                domain={[0, "auto"]}
              />
              <YAxis
                type="category"
                dataKey="platform"
                tick={{ fill: "#cbd5e1", fontSize: 13 }}
                tickLine={false}
                axisLine={{ stroke: CHART.axis }}
                width={82}
              />
              <Tooltip
                cursor={{ fill: CHART.barHover }}
                content={(props) => <PlatformTooltip {...props} metric={metric} />}
              />
              <Bar
                dataKey={metric}
                barSize={20}
                radius={[0, 4, 4, 0]}
                isAnimationActive={false}
              >
                {data.map((d) => (
                  <Cell key={d.platform} fill={platformColor(d.platform)} />
                ))}
                <LabelList
                  dataKey={metric}
                  position="right"
                  fill="#e2e8f0"
                  fontSize={12}
                  formatter={(v: unknown) =>
                    metric === "engagementRate"
                      ? `${Number(v).toFixed(1)}%`
                      : formatAxisMetric(metric, Number(v))
                  }
                />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="overflow-auto rounded-lg border border-white/[0.07]">
          <table className="w-full text-sm">
            <caption className="sr-only">Platform performance values</caption>
            <thead className="bg-navy-800 text-left text-xs text-slate-400">
              <tr>
                <th scope="col" className="px-3 py-2 font-medium">Platform</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Posts</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Engagement rate</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Reach</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Interactions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05] tabular-nums">
              {data.map((p) => (
                <tr key={p.platform}>
                  <th scope="row" className="px-3 py-2 text-left font-normal text-slate-200">
                    <span className="inline-flex items-center gap-2">
                      <span className="h-2 w-2 rounded-sm" style={{ background: platformColor(p.platform) }} />
                      {p.platform}
                    </span>
                  </th>
                  <td className="px-3 py-2 text-right text-slate-300">{p.posts}</td>
                  <td className="px-3 py-2 text-right text-slate-300">{formatMetric("engagementRate", p.engagementRate)}</td>
                  <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.reach)}</td>
                  <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.interactions)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
