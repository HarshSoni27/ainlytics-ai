import type { MetricKey } from "@/lib/types";
import { formatCompact, formatInt, formatPercent } from "@/lib/format";

/**
 * Chart colours. The categorical set is the dark-surface palette from the data-viz skill,
 * validated (lightness band, chroma, colour-blind separation, contrast) against this
 * app's navy card surface #131c3a.
 */
const SERIES_DARK = [
  "#3987e5", // blue
  "#d95926", // orange
  "#199e70", // aqua
  "#c98500", // yellow
  "#d55181", // magenta
  "#0ca30c", // green
  "#9085e9", // violet
  "#e66767", // red
] as const;

/** Each platform keeps the same colour everywhere (colour follows the entity, not its rank). */
const PLATFORM_ORDER = [
  "Instagram",
  "TikTok",
  "LinkedIn",
  "Facebook",
  "X",
  "YouTube",
  "Threads",
  "Pinterest",
];

const OTHER_COLOR = "#94a3b8";

export function platformColor(platform: string): string {
  const i = PLATFORM_ORDER.indexOf(platform);
  return i >= 0 ? SERIES_DARK[i] : OTHER_COLOR;
}

export const CHART = {
  surface: "#131c3a",
  grid: "rgba(148, 163, 184, 0.12)",
  axis: "rgba(148, 163, 184, 0.25)",
  tick: "#94a3b8",
  /** Single-series charts use the brand accent. */
  line: "#a78bfa",
  cursor: "rgba(148, 163, 184, 0.35)",
  barHover: "rgba(255, 255, 255, 0.05)",
} as const;

export const METRIC_OPTIONS: { value: MetricKey; label: string }[] = [
  { value: "engagementRate", label: "Engagement rate" },
  { value: "reach", label: "Reach" },
  { value: "interactions", label: "Interactions" },
];

export const METRIC_LABEL: Record<MetricKey, string> = {
  engagementRate: "Engagement rate",
  reach: "Reach",
  interactions: "Interactions",
};

export function formatMetric(metric: MetricKey, value: number): string {
  return metric === "engagementRate" ? formatPercent(value) : formatInt(value);
}

export function formatAxisMetric(metric: MetricKey, value: number): string {
  return metric === "engagementRate" ? `${value}%` : formatCompact(value);
}
