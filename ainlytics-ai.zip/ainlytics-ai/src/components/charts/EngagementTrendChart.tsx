"use client";

import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipContentProps,
} from "recharts";
import type { NameType, ValueType } from "recharts/types/component/DefaultTooltipContent";
import { formatInt } from "@/lib/format";
import { buildTrend } from "@/lib/metrics";
import type { MetricKey, Post, TrendPoint } from "@/lib/types";
import { Card, CardHeader, Segmented } from "../ui";
import {
  CHART,
  formatAxisMetric,
  formatMetric,
  METRIC_LABEL,
  METRIC_OPTIONS,
} from "./chartTheme";

type View = "chart" | "table";

function TrendTooltip({
  active,
  payload,
  metric,
}: Partial<TooltipContentProps<ValueType, NameType>> & { metric: MetricKey }) {
  if (!active || !payload || payload.length === 0) return null;
  const point = payload[0].payload as TrendPoint;
  return (
    <div className="rounded-lg border border-white/10 bg-navy-700 px-3 py-2.5 text-xs shadow-xl">
      <p className="mb-1.5 text-slate-400">{point.label}</p>
      <p className="flex items-center gap-2">
        <span className="h-0.5 w-3 rounded" style={{ background: CHART.line }} />
        <span className="text-sm font-semibold text-white">
          {formatMetric(metric, point[metric])}
        </span>
        <span className="text-slate-400">{METRIC_LABEL[metric]}</span>
      </p>
      <p className="mt-1 text-slate-500">
        {point.posts} post{point.posts === 1 ? "" : "s"}
      </p>
    </div>
  );
}

export function EngagementTrendChart({ posts }: { posts: Post[] }) {
  const [metric, setMetric] = useState<MetricKey>("engagementRate");
  const [view, setView] = useState<View>("chart");
  const { points, granularity } = useMemo(() => buildTrend(posts), [posts]);

  return (
    <Card>
      <CardHeader
        title="Engagement trend"
        description={`${METRIC_LABEL[metric]} by ${granularity}${granularity === "week" ? " (weeks start Monday)" : ""}`}
        actions={
          <div className="flex flex-wrap gap-2">
            <Segmented
              label="Metric"
              value={metric}
              options={METRIC_OPTIONS}
              onChange={setMetric}
            />
            <Segmented
              label="View"
              value={view}
              options={[
                { value: "chart", label: "Chart" },
                { value: "table", label: "Table" },
              ]}
              onChange={setView}
            />
          </div>
        }
      />

      {points.length === 0 ? (
        <p className="py-16 text-center text-sm text-slate-400">
          No posts in this selection.
        </p>
      ) : view === "chart" ? (
        <div
          role="img"
          aria-label={`${METRIC_LABEL[metric]} by ${granularity}, ${points.length} data points. Switch to table view for the values.`}
          className="h-72 w-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={points} margin={{ top: 8, right: 12, bottom: 0, left: 0 }}>
              <CartesianGrid stroke={CHART.grid} vertical={false} />
              <XAxis
                dataKey="label"
                tick={{ fill: CHART.tick, fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: CHART.axis }}
                interval="preserveStartEnd"
                minTickGap={28}
              />
              <YAxis
                tick={{ fill: CHART.tick, fontSize: 12 }}
                tickLine={false}
                axisLine={false}
                width={48}
                tickFormatter={(v: number) => formatAxisMetric(metric, v)}
                domain={[0, "auto"]}
              />
              <Tooltip
                cursor={{ stroke: CHART.cursor, strokeWidth: 1 }}
                content={(props) => <TrendTooltip {...props} metric={metric} />}
              />
              <Area
                type="monotone"
                dataKey={metric}
                stroke={CHART.line}
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
                fill={CHART.line}
                fillOpacity={0.1}
                dot={false}
                activeDot={{ r: 4.5, fill: CHART.line, stroke: CHART.surface, strokeWidth: 2 }}
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="max-h-72 overflow-auto rounded-lg border border-white/[0.07]">
          <table className="w-full text-sm">
            <caption className="sr-only">Engagement trend values</caption>
            <thead className="sticky top-0 bg-navy-800 text-left text-xs text-slate-400">
              <tr>
                <th scope="col" className="px-3 py-2 font-medium">Period</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Posts</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Engagement rate</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Reach</th>
                <th scope="col" className="px-3 py-2 text-right font-medium">Interactions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05] tabular-nums">
              {points.map((p) => (
                <tr key={p.date}>
                  <th scope="row" className="px-3 py-2 text-left font-normal text-slate-300">
                    {p.label}
                  </th>
                  <td className="px-3 py-2 text-right text-slate-300">{p.posts}</td>
                  <td className="px-3 py-2 text-right text-slate-300">{formatMetric("engagementRate", p.engagementRate)}</td>
                  <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.reach)}</td>
                  <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.interactions)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
