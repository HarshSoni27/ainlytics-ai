"use client";

import { addDays } from "@/lib/metrics";
import { ALL_PLATFORMS } from "@/lib/metrics";
import type { PostFilters } from "@/lib/types";
import { CONTROL_CLASS, Button, Field, cx } from "./ui";

const PRESETS = [
  { label: "7 days", days: 7 },
  { label: "30 days", days: 30 },
  { label: "90 days", days: 90 },
] as const;

export const DEFAULT_FILTERS: PostFilters = { from: "", to: "", platform: ALL_PLATFORMS };

export function isRangeInvalid(f: PostFilters): boolean {
  return Boolean(f.from && f.to && f.from > f.to);
}

export function Filters({
  filters,
  onChange,
  platforms,
  range,
}: {
  filters: PostFilters;
  onChange: (next: PostFilters) => void;
  platforms: string[];
  /** Earliest and latest post dates in the full dataset. */
  range: { min: string; max: string } | null;
}) {
  const invalid = isRangeInvalid(filters);
  const isActive =
    filters.from !== "" || filters.to !== "" || filters.platform !== ALL_PLATFORMS;

  // Presets count back from the newest post in the data (not from today), so an older
  // CSV still shows results.
  const presetActive = (days: number | null): boolean => {
    if (!range) return false;
    if (days === null) return filters.from === "" && filters.to === "";
    return filters.from === addDays(range.max, -(days - 1)) && filters.to === range.max;
  };

  const applyPreset = (days: number | null) => {
    if (!range) return;
    if (days === null) onChange({ ...filters, from: "", to: "" });
    else onChange({ ...filters, from: addDays(range.max, -(days - 1)), to: range.max });
  };

  return (
    <div className="mb-6 rounded-xl border border-white/[0.07] bg-navy-850 p-4">
      <div className="flex flex-wrap items-end gap-x-4 gap-y-3">
        <div role="group" aria-label="Quick date ranges" className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-slate-400">Date range</span>
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button
                key={p.days}
                type="button"
                disabled={!range}
                aria-pressed={presetActive(p.days)}
                onClick={() => applyPreset(p.days)}
                className={cx(
                  "h-10 rounded-lg border px-3 text-sm transition-colors disabled:opacity-50",
                  presetActive(p.days)
                    ? "border-accent-500/60 bg-accent-500/15 text-white"
                    : "border-white/10 bg-navy-900 text-slate-300 hover:border-white/20",
                )}
              >
                Last {p.label}
              </button>
            ))}
            <button
              type="button"
              disabled={!range}
              aria-pressed={presetActive(null)}
              onClick={() => applyPreset(null)}
              className={cx(
                "h-10 rounded-lg border px-3 text-sm transition-colors disabled:opacity-50",
                presetActive(null)
                  ? "border-accent-500/60 bg-accent-500/15 text-white"
                  : "border-white/10 bg-navy-900 text-slate-300 hover:border-white/20",
              )}
            >
              All time
            </button>
          </div>
        </div>

        <Field label="From" htmlFor="filter-from">
          <input
            id="filter-from"
            type="date"
            value={filters.from}
            min={range?.min}
            max={range?.max}
            onChange={(e) => onChange({ ...filters, from: e.target.value })}
            className={CONTROL_CLASS}
            aria-invalid={invalid}
          />
        </Field>

        <Field label="To" htmlFor="filter-to">
          <input
            id="filter-to"
            type="date"
            value={filters.to}
            min={range?.min}
            max={range?.max}
            onChange={(e) => onChange({ ...filters, to: e.target.value })}
            className={CONTROL_CLASS}
            aria-invalid={invalid}
          />
        </Field>

        <Field label="Platform" htmlFor="filter-platform">
          <select
            id="filter-platform"
            value={filters.platform}
            onChange={(e) => onChange({ ...filters, platform: e.target.value })}
            className={cx(CONTROL_CLASS, "min-w-40")}
          >
            <option value={ALL_PLATFORMS}>All platforms</option>
            {platforms.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </Field>

        {isActive && (
          <Button variant="ghost" onClick={() => onChange(DEFAULT_FILTERS)} className="h-10">
            Clear filters
          </Button>
        )}
      </div>

      {invalid && (
        <p role="alert" className="mt-3 text-sm text-amber-300">
          The start date is after the end date, so the date range is ignored until you fix it.
        </p>
      )}
    </div>
  );
}
