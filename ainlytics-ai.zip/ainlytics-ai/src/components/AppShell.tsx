"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { useAnalyticsData } from "@/lib/useAnalyticsData";
import {
  CloseIcon,
  DashboardIcon,
  MenuIcon,
  PostsIcon,
  SettingsIcon,
  SparkIcon,
  UploadIcon,
} from "./icons";
import { Alert, Badge, cx } from "./ui";

const NAV = [
  { href: "/", label: "Dashboard", Icon: DashboardIcon },
  { href: "/upload", label: "Upload CSV", Icon: UploadIcon },
  { href: "/posts", label: "Posts", Icon: PostsIcon },
  { href: "/insights", label: "AI Insights", Icon: SparkIcon },
  { href: "/settings", label: "Settings", Icon: SettingsIcon },
] as const;

function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-accent-500 to-accent-700 text-white">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M4 18 9 11l4 4 7-10"
            stroke="currentColor"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span className="text-[1.05rem] font-semibold tracking-tight text-white">
        Ainlytics <span className="text-accent-400">AI</span>
      </span>
    </div>
  );
}

function SidebarContent({ onNavigate }: { onNavigate: () => void }) {
  const pathname = usePathname();
  const { source, posts, isLoading } = useAnalyticsData();

  return (
    <div className="flex h-full flex-col">
      <div className="px-5 py-5">
        <Link href="/" onClick={onNavigate} aria-label="Ainlytics AI home">
          <Logo />
        </Link>
      </div>

      <nav aria-label="Main" className="flex-1 px-3">
        <ul className="space-y-1">
          {NAV.map(({ href, label, Icon }) => {
            const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
            return (
              <li key={href}>
                <Link
                  href={href}
                  onClick={onNavigate}
                  aria-current={active ? "page" : undefined}
                  className={cx(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    active
                      ? "bg-accent-500/15 text-white"
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-100",
                  )}
                >
                  <Icon className={active ? "text-accent-400" : ""} />
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="m-3 rounded-lg border border-white/[0.07] bg-navy-850 p-3">
        <p className="text-xs text-slate-500">Current data</p>
        <div className="mt-1.5 flex flex-wrap items-center gap-2">
          {isLoading ? (
            <span className="text-sm text-slate-500">Loading…</span>
          ) : source === "demo" ? (
            <Badge tone="accent">Demo data</Badge>
          ) : source === "imported" ? (
            <Badge tone="good">Imported</Badge>
          ) : (
            <Badge tone="warn">No data</Badge>
          )}
          {!isLoading && (
            <span className="text-sm text-slate-300">
              {posts.length.toLocaleString("en-US")} posts
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dismissedError, setDismissedError] = useState<string | null>(null);
  const { storageError } = useAnalyticsData();

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="min-h-screen lg:flex">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-white/[0.06] bg-navy-900 lg:block">
        <SidebarContent onNavigate={closeMenu} />
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-white/[0.06] bg-navy-900/95 px-4 py-3 backdrop-blur lg:hidden">
        <Logo />
        <button
          type="button"
          onClick={() => setMenuOpen(true)}
          aria-label="Open navigation menu"
          aria-expanded={menuOpen}
          className="rounded-lg p-2 text-slate-300 hover:bg-white/5"
        >
          <MenuIcon />
        </button>
      </header>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
          <div className="absolute inset-0 bg-navy-950/80" onClick={closeMenu} aria-hidden="true" />
          <div className="relative h-full w-72 max-w-[85vw] border-r border-white/[0.06] bg-navy-900">
            <button
              type="button"
              onClick={closeMenu}
              aria-label="Close navigation menu"
              className="absolute right-3 top-4 rounded-lg p-2 text-slate-400 hover:bg-white/5"
            >
              <CloseIcon />
            </button>
            <SidebarContent onNavigate={closeMenu} />
          </div>
        </div>
      )}

      <main className="min-w-0 flex-1 lg:pl-64">
        <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          {storageError && storageError !== dismissedError && (
            <div className="mb-6">
              <Alert
                tone="warning"
                title="Storage notice"
                onDismiss={() => setDismissedError(storageError)}
              >
                {storageError}
              </Alert>
            </div>
          )}
          {children}
        </div>
      </main>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        <h1 className="text-2xl font-semibold tracking-tight text-white sm:text-[1.75rem]">
          {title}
        </h1>
        {description && (
          <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-slate-400">
            {description}
          </p>
        )}
      </div>
      {actions}
    </div>
  );
}
