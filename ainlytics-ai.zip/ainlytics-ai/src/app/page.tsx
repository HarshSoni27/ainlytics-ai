"use client";

import { useMemo, useState } from "react";
import { PlatformChart } from "@/components/charts/PlatformChart";
import { EngagementTrendChart } from "@/components/charts/EngagementTrendChart";
import { PageHeader } from "@/components/AppShell";
import { DEFAULT_FILTERS, Filters, isRangeInvalid } from "@/components/Filters";
import { MetricCard, MetricCardSkeleton } from "@/components/MetricCard";
import { NoDataState } from "@/components/NoDataState";
import { PostDetailPanel } from "@/components/PostDetailPanel";
import { TopPostsTable } from "@/components/TopPostsTable";
import { Button, ButtonLink, EmptyState, Skeleton } from "@/components/ui";
import { UploadIcon } from "@/components/icons";
import { formatDate, formatInt, formatPercent } from "@/lib/format";
import { dateRange, filterPosts, summarize, uniquePlatforms } from "@/lib/metrics";
import type { Post, PostFilters } from "@/lib/types";
import { useAnalyticsData } from "@/lib/useAnalyticsData";

export default function DashboardPage() {
  const { posts, isLoading, source } = useAnalyticsData();
  const [filters, setFilters] = useState<PostFilters>(DEFAULT_FILTERS);
  const [selected, setSelected] = useState<Post | null>(null);

  const platforms = useMemo(() => uniquePlatforms(posts), [posts]);
  const range = useMemo(() => dateRange(posts), [posts]);

  // What the filter bar shows: exactly what the user chose, except that a platform which no
  // longer exists (e.g. after importing new data) falls back to "all".
  const shownFilters: PostFilters = useMemo(
    () => ({
      ...filters,
      platform: platforms.includes(filters.platform) ? filters.platform : DEFAULT_FILTERS.platform,
    }),
    [filters, platforms],
  );

  // What the numbers use: an inverted date range is ignored (and the filter bar warns about
  // it) rather than silently returning nothing.
  const effectiveFilters: PostFilters = useMemo(
    () => (isRangeInvalid(shownFilters) ? { ...shownFilters, from: "", to: "" } : shownFilters),
    [shownFilters],
  );

  const filtered = useMemo(() => filterPosts(posts, effectiveFilters), [posts, effectiveFilters]);
  const summary = useMemo(() => summarize(filtered), [filtered]);

  const subtitle =
    source === "demo"
      ? "You're looking at demo data for a fictional coffee brand. Upload a CSV to see your own numbers."
      : "Performance of your social media posts, calculated from the data you imported.";

  return (
    <>
      <PageHeader
        title="Dashboard"
        description={subtitle}
        actions={
          <ButtonLink href="/upload" variant="primary">
            <UploadIcon width={18} height={18} />
            Upload CSV
          </ButtonLink>
        }
      />

      {isLoading ? (
        <DashboardSkeleton />
      ) : posts.length === 0 ? (
        <NoDataState />
      ) : (
        <>
          <Filters
            filters={shownFilters}
            onChange={setFilters}
            platforms={platforms}
            range={range}
          />

          {filtered.length === 0 ? (
            <EmptyState
              title="No posts match these filters"
              actions={<Button onClick={() => setFilters(DEFAULT_FILTERS)}>Clear filters</Button>}
            >
              Try a wider date range or a different platform.
            </EmptyState>
          ) : (
            <div className="space-y-6">
              <p className="text-sm text-slate-400">
                Showing {formatInt(filtered.length)} of {formatInt(posts.length)} posts
                {range && (
                  <>
                    {" "}
                    · data from {formatDate(range.min)} to {formatDate(range.max)}
                  </>
                )}
              </p>

              <section aria-label="Key metrics" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
                <MetricCard
                  featured
                  className="col-span-2"
                  label="Average engagement rate"
                  value={formatPercent(summary.avgEngagementRate)}
                  hint={
                    summary.zeroReachPosts > 0
                      ? `(likes + comments + shares) ÷ reach × 100, averaged per post. ${summary.zeroReachPosts} zero-reach post${summary.zeroReachPosts === 1 ? " is" : "s are"} left out.`
                      : "(likes + comments + shares) ÷ reach × 100, averaged per post."
                  }
                />
                <MetricCard label="Total reach" value={formatInt(summary.totalReach)} />
                <MetricCard label="Total impressions" value={formatInt(summary.totalImpressions)} />
                <MetricCard label="Total posts" value={formatInt(summary.totalPosts)} />
                <MetricCard label="Total likes" value={formatInt(summary.totalLikes)} />
                <MetricCard label="Total comments" value={formatInt(summary.totalComments)} />
                <MetricCard label="Total shares" value={formatInt(summary.totalShares)} />
              </section>

              <div className="grid gap-6 xl:grid-cols-2">
                <EngagementTrendChart posts={filtered} />
                <PlatformChart posts={filtered} />
              </div>

              <TopPostsTable posts={filtered} onSelect={setSelected} />
            </div>
          )}
        </>
      )}

      <PostDetailPanel post={selected} allPosts={posts} onClose={() => setSelected(null)} />
    </>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Loading dashboard">
      <Skeleton className="h-24 w-full" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <MetricCardSkeleton featured className="col-span-2" />
        <MetricCardSkeleton />
        <MetricCardSkeleton />
        <MetricCardSkeleton />
        <MetricCardSkeleton />
        <MetricCardSkeleton />
        <MetricCardSkeleton />
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <Skeleton className="h-96" />
        <Skeleton className="h-96" />
      </div>
    </div>
  );
}
