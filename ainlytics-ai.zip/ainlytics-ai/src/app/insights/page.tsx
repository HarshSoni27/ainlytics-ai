"use client";

import { useEffect, useMemo, useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { platformColor } from "@/components/charts/chartTheme";
import { NoDataState } from "@/components/NoDataState";
import { PostDetailPanel } from "@/components/PostDetailPanel";
import { Alert, Badge, Button, Card, CardHeader, CONTROL_CLASS, Skeleton, Spinner } from "@/components/ui";
import { formatDate, formatPercent, truncate } from "@/lib/format";
import {
  analyzeLocally,
  buildAiPayload,
  type AiInsightsResponse,
  type Pattern,
  type RankedPost,
} from "@/lib/insights";
import type { Post } from "@/lib/types";
import { useAnalyticsData } from "@/lib/useAnalyticsData";

const TONE_DOT: Record<Pattern["tone"], string> = {
  positive: "bg-emerald-400",
  negative: "bg-red-400",
  neutral: "bg-slate-400",
};
const TONE_LABEL: Record<Pattern["tone"], string> = {
  positive: "Positive",
  negative: "Needs attention",
  neutral: "Neutral",
};

interface AiResult {
  model: string;
  insights: AiInsightsResponse;
}

export default function InsightsPage() {
  const { posts, isLoading } = useAnalyticsData();
  const [selected, setSelected] = useState<Post | null>(null);
  const insights = useMemo(() => analyzeLocally(posts), [posts]);

  return (
    <>
      <PageHeader
        title="AI Insights"
        description="Patterns, suggestions and post ideas generated from your current data."
      />

      {isLoading ? (
        <div className="space-y-4" aria-busy="true" aria-label="Loading insights">
          <Skeleton className="h-28" />
          <Skeleton className="h-64" />
        </div>
      ) : posts.length === 0 ? (
        <NoDataState />
      ) : (
        <div className="space-y-6">
          <AiPanel posts={posts} />

          <section aria-labelledby="local-heading" className="space-y-6">
            <div className="flex flex-wrap items-center gap-3">
              <h2 id="local-heading" className="text-xl font-semibold text-white">
                Local analysis
              </h2>
              <Badge tone="neutral">Rule-based statistics, not an AI model</Badge>
            </div>

            <Alert tone="info">
              This section is calculated in your browser from your {posts.length} posts using fixed rules (averages,
              comparisons and templates). No AI model wrote it.
            </Alert>

            <p className="text-base leading-relaxed text-slate-200">{insights.headline}</p>

            {insights.hasEnoughData && (
              <>
                <div className="grid gap-6 lg:grid-cols-2">
                  <PostList
                    title="Best performing posts"
                    description="Highest engagement rate"
                    items={insights.best}
                    onSelect={setSelected}
                  />
                  <PostList
                    title="Worst performing posts"
                    description="Lowest engagement rate"
                    items={insights.worst}
                    onSelect={setSelected}
                  />
                </div>

                <Card>
                  <CardHeader
                    title="Engagement patterns"
                    description="Comparisons are adjusted for platform, so a TikTok post is judged against other TikTok posts."
                  />
                  <ul className="divide-y divide-white/[0.06]">
                    {insights.patterns.map((p) => (
                      <li key={p.id} className="flex gap-3 py-3.5 first:pt-0 last:pb-0">
                        <span
                          className={`mt-2 h-2 w-2 shrink-0 rounded-full ${TONE_DOT[p.tone]}`}
                          aria-hidden="true"
                        />
                        <div>
                          <p className="font-medium text-slate-100">
                            {p.title} <span className="sr-only">({TONE_LABEL[p.tone]})</span>
                          </p>
                          <p className="mt-0.5 text-sm leading-relaxed text-slate-400">{p.detail}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </Card>

                <Card>
                  <CardHeader title="Content improvement suggestions" />
                  <ul className="grid gap-4 md:grid-cols-2">
                    {insights.suggestions.map((s) => (
                      <li key={s.id} className="rounded-lg border border-white/[0.07] bg-navy-900 p-4">
                        <p className="font-medium text-slate-100">{s.title}</p>
                        <p className="mt-1 text-sm leading-relaxed text-slate-400">{s.detail}</p>
                      </li>
                    ))}
                  </ul>
                </Card>

                <Card>
                  <CardHeader
                    title="Three post ideas to try next"
                    description="Template-based ideas built from your own top posts, platforms and best days."
                  />
                  <ol className="grid gap-4 lg:grid-cols-3">
                    {insights.ideas.map((idea) => (
                      <li key={idea.id} className="flex flex-col rounded-lg border border-white/[0.07] bg-navy-900 p-4">
                        <p className="flex items-center gap-2 text-xs text-slate-400">
                          <span className="h-2 w-2 rounded-sm" style={{ background: platformColor(idea.platform) }} />
                          {idea.platform} · {idea.format}
                        </p>
                        <p className="mt-2 font-medium text-slate-100">{idea.title}</p>
                        <p className="mt-2 rounded-md bg-white/[0.04] p-3 text-sm leading-relaxed text-slate-200">
                          {idea.caption}
                        </p>
                        <p className="mt-3 text-xs leading-relaxed text-slate-400">{idea.rationale}</p>
                      </li>
                    ))}
                  </ol>
                </Card>
              </>
            )}

            <ul className="space-y-1 text-xs leading-relaxed text-slate-500">
              {insights.caveats.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          </section>
        </div>
      )}

      <PostDetailPanel post={selected} allPosts={posts} onClose={() => setSelected(null)} />
    </>
  );
}

function PostList({
  title,
  description,
  items,
  onSelect,
}: {
  title: string;
  description: string;
  items: RankedPost[];
  onSelect: (p: Post) => void;
}) {
  return (
    <Card>
      <CardHeader title={title} description={description} />
      <ul className="space-y-3">
        {items.map(({ post, rate }) => (
          <li key={post.id}>
            <button
              type="button"
              onClick={() => onSelect(post)}
              className="flex w-full items-start justify-between gap-4 rounded-lg border border-white/[0.07] bg-navy-900 p-3 text-left transition-colors hover:border-accent-500/40"
            >
              <span className="min-w-0">
                <span className="block text-sm text-slate-100">{truncate(post.caption, 90)}</span>
                <span className="mt-1 flex items-center gap-2 text-xs text-slate-500">
                  <span className="h-2 w-2 rounded-sm" style={{ background: platformColor(post.platform) }} />
                  {post.platform} · {formatDate(post.date)}
                </span>
              </span>
              <span className="shrink-0 text-base font-semibold tabular-nums text-white">{formatPercent(rate)}</span>
            </button>
          </li>
        ))}
      </ul>
    </Card>
  );
}

function AiPanel({ posts }: { posts: Post[] }) {
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [requiresCode, setRequiresCode] = useState(false);
  const [accessCode, setAccessCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AiResult | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/insights")
      .then((r) => (r.ok ? r.json() : { configured: false }))
      .then((d: { configured?: boolean; requiresCode?: boolean }) => {
        if (cancelled) return;
        setConfigured(Boolean(d.configured));
        setRequiresCode(Boolean(d.requiresCode));
      })
      .catch(() => {
        if (!cancelled) setConfigured(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function generate() {
    if (requiresCode && accessCode.trim() === "") {
      setError("Enter the access code first.");
      return;
    }
    const payload = buildAiPayload(posts);
    if (!payload) {
      setError("You need at least one post with reach to generate AI insights.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/insights", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          ...(requiresCode ? { "x-access-code": accessCode } : {}),
        },
        body: JSON.stringify(payload),
      });
      const data = (await res.json().catch(() => null)) as
        | { error?: string; model?: string; insights?: AiInsightsResponse }
        | null;
      if (!res.ok || !data?.insights || !data.model) {
        setError(data?.error ?? "Something went wrong while generating AI insights.");
        setResult(null);
      } else {
        setResult({ model: data.model, insights: data.insights });
      }
    } catch {
      setError("Couldn't reach the server. Check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader
        title="AI-generated insights"
        description="Optional. Sends a compact summary of your numbers (totals, platform averages and up to 10 captions), not your whole file, to an AI model through this app's server."
        actions={result ? <Badge tone="accent">Generated by AI model: {result.model}</Badge> : undefined}
      />

      {configured === null && <Spinner label="Checking AI availability…" />}

      {configured === false && (
        <Alert tone="info" title="AI is not set up">
          AI insights are turned off on this server, so this app is using the local analysis below. The site owner
          can turn them on with server settings described in the README.
        </Alert>
      )}

      {configured && (
        <div className="space-y-4">
          {requiresCode && (
            <div className="flex max-w-xs flex-col gap-1.5">
              <label htmlFor="ai-access-code" className="text-xs font-medium text-slate-400">
                Access code
              </label>
              <input
                id="ai-access-code"
                type="password"
                autoComplete="off"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                className={CONTROL_CLASS}
              />
            </div>
          )}
          <Button variant="primary" onClick={generate} disabled={loading}>
            {loading ? "Generating…" : result ? "Regenerate with AI" : "Generate AI insights"}
          </Button>
          {loading && <Spinner label="Asking the AI model. This can take 10–20 seconds…" />}
          {error && <Alert tone="error" title="AI insights failed">{error}</Alert>}

          {result && !loading && (
            <div className="space-y-5 border-t border-white/[0.07] pt-5">
              <p className="text-base leading-relaxed text-slate-100">{result.insights.summary}</p>
              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <h3 className="mb-2 text-sm font-medium text-slate-300">Patterns</h3>
                  <ul className="list-disc space-y-1.5 pl-5 text-sm leading-relaxed text-slate-300">
                    {result.insights.patterns.map((p) => (
                      <li key={p}>{p}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="mb-2 text-sm font-medium text-slate-300">Suggestions</h3>
                  <ul className="list-disc space-y-1.5 pl-5 text-sm leading-relaxed text-slate-300">
                    {result.insights.suggestions.map((s) => (
                      <li key={s}>{s}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <div>
                <h3 className="mb-2 text-sm font-medium text-slate-300">Post ideas</h3>
                <ol className="grid gap-3 md:grid-cols-3">
                  {result.insights.postIdeas.map((i) => (
                    <li key={i.title} className="rounded-lg border border-white/[0.07] bg-navy-900 p-4">
                      <p className="text-xs text-slate-400">{i.platform}</p>
                      <p className="mt-1 font-medium text-slate-100">{i.title}</p>
                      <p className="mt-2 text-sm leading-relaxed text-slate-300">{i.idea}</p>
                    </li>
                  ))}
                </ol>
              </div>
              <p className="text-xs text-slate-500">
                AI output can be wrong. Check it against your own numbers before acting on it.
              </p>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
