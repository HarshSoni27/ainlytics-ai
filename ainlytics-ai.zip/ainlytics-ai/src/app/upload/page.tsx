"use client";

import { useRef, useState, type DragEvent } from "react";
import { PageHeader } from "@/components/AppShell";
import { DownloadIcon, FileIcon, UploadIcon } from "@/components/icons";
import { Alert, Badge, Button, ButtonLink, Card, CardHeader, Spinner, cx } from "@/components/ui";
import { MAX_FILE_BYTES, MAX_ROWS, parseCsvFile, REQUIRED_COLUMNS } from "@/lib/csv";
import { formatInt, formatPercent, truncate } from "@/lib/format";
import { engagementRate } from "@/lib/metrics";
import type { ImportResult, ImportMode } from "@/lib/store";
import type { CsvParseResult } from "@/lib/types";
import { useAnalyticsData } from "@/lib/useAnalyticsData";

const PREVIEW_ROWS = 10;
const MAX_LISTED_ISSUES = 50;

const COLUMN_HELP: { name: string; required: boolean; description: string; example: string }[] = [
  { name: "date", required: true, description: "Publish date as YYYY-MM-DD", example: "2026-11-20" },
  { name: "platform", required: true, description: "Where it was posted", example: "Instagram" },
  { name: "caption", required: true, description: "Post text (can be blank)", example: "New roast is here" },
  { name: "likes", required: true, description: "Whole number, 0 or more", example: "420" },
  { name: "comments", required: true, description: "Whole number, 0 or more", example: "36" },
  { name: "shares", required: true, description: "Whole number, 0 or more", example: "18" },
  { name: "reach", required: true, description: "Unique people reached", example: "8200" },
  { name: "impressions", required: true, description: "Total views", example: "11050" },
  { name: "content_type", required: false, description: "Format, e.g. Image, Video, Reel", example: "Reel" },
];

export default function UploadPage() {
  const { source, posts: currentPosts, importPosts } = useAnalyticsData();
  const inputRef = useRef<HTMLInputElement>(null);

  const [parsing, setParsing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [result, setResult] = useState<CsvParseResult | null>(null);
  const [mode, setMode] = useState<ImportMode>("replace");
  const [imported, setImported] = useState<ImportResult | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function handleFile(file: File) {
    setParsing(true);
    setImported(null);
    setNotice(null);
    setFileName(file.name);
    // Let the spinner paint before the (synchronous) parse starts.
    await new Promise((r) => setTimeout(r, 0));
    const parsed = await parseCsvFile(file);
    setResult(parsed);
    setParsing(false);
  }

  function onDrop(e: DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length === 0) return;
    if (files.length > 1) setNotice("You dropped more than one file, so only the first was used.");
    void handleFile(files[0]);
  }

  function reset() {
    setResult(null);
    setFileName(null);
    setImported(null);
    setNotice(null);
  }

  function runImport() {
    if (!result || result.posts.length === 0) return;
    const outcome = importPosts(result.posts, mode);
    setImported(outcome);
    if (outcome.added > 0 || outcome.ok) setResult(null);
  }

  const canChooseMode = source === "imported" && currentPosts.length > 0;
  const importable = result && !result.fatalError && result.posts.length > 0;

  return (
    <>
      <PageHeader
        title="Upload CSV"
        description="Import your social media post analytics. Every dashboard number is recalculated from the file you upload."
      />

      <div className="space-y-6">
        {/* Dropzone */}
        <Card>
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            className={cx(
              "flex flex-col items-center rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors",
              dragOver ? "border-accent-400 bg-accent-500/10" : "border-white/10 bg-navy-900/50",
            )}
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-accent-500/15 text-accent-300">
              <UploadIcon width={24} height={24} />
            </span>
            <p className="mt-4 text-base font-medium text-slate-100">Drag a CSV file here</p>
            <p className="mt-1 text-sm text-slate-400">
              or choose one from your computer (up to {MAX_FILE_BYTES / 1024 / 1024} MB and {formatInt(MAX_ROWS)} rows)
            </p>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <Button variant="primary" onClick={() => inputRef.current?.click()} disabled={parsing}>
                Choose CSV file
              </Button>
              <ButtonLink href="/sample-posts.csv" download>
                <DownloadIcon width={18} height={18} />
                Download sample CSV
              </ButtonLink>
            </div>
            <input
              ref={inputRef}
              type="file"
              accept=".csv,text/csv"
              className="sr-only"
              aria-label="Choose a CSV file to import"
              tabIndex={-1}
              onChange={(e) => {
                const file = e.target.files?.[0];
                e.target.value = ""; // allow picking the same file again
                if (file) void handleFile(file);
              }}
            />
            <p className="mt-4 text-xs text-slate-500">
              Want to see how errors look?{" "}
              <a
                href="/sample-posts-with-errors.csv"
                download
                className="text-accent-300 underline underline-offset-2 hover:text-accent-400"
              >
                Download a sample with deliberate mistakes
              </a>
              .
            </p>
          </div>
          {notice && (
            <div className="mt-4">
              <Alert tone="info">{notice}</Alert>
            </div>
          )}
        </Card>

        {parsing && (
          <Card>
            <Spinner label={`Reading ${fileName ?? "file"}…`} />
          </Card>
        )}

        {/* Success */}
        {imported && (
          <div className="space-y-4">
            {imported.ok ? (
              <Alert tone="success" title={`Imported ${formatInt(imported.added)} post${imported.added === 1 ? "" : "s"}`}>
                {imported.duplicates > 0 && (
                  <>{formatInt(imported.duplicates)} duplicate{imported.duplicates === 1 ? " was" : "s were"} skipped. </>
                )}
                You now have {formatInt(imported.total)} posts. The dashboard, posts and insights have been updated.
              </Alert>
            ) : (
              <Alert tone="error" title="The import didn't finish">
                {imported.error}
              </Alert>
            )}
            <div className="flex flex-wrap gap-3">
              <ButtonLink href="/" variant="primary">View dashboard</ButtonLink>
              <ButtonLink href="/insights">See insights</ButtonLink>
              <Button onClick={reset}>Upload another file</Button>
            </div>
          </div>
        )}

        {/* Validation result */}
        {result && !parsing && (
          <>
            {result.fatalError ? (
              <Alert tone="error" title={`We couldn't import ${fileName ?? "this file"}`}>
                {result.fatalError}
              </Alert>
            ) : (
              <Card>
                <CardHeader
                  title={fileName ?? "Your file"}
                  description={`${formatInt(result.totalRows)} data row${result.totalRows === 1 ? "" : "s"} found`}
                  actions={
                    <div className="flex flex-wrap gap-2">
                      <Badge tone={result.posts.length > 0 ? "good" : "bad"}>
                        {formatInt(result.posts.length)} ready to import
                      </Badge>
                      {result.errors.length > 0 && (
                        <Badge tone="bad">{formatInt(result.errors.length)} skipped</Badge>
                      )}
                      {result.warnings.length > 0 && (
                        <Badge tone="warn">{formatInt(result.warnings.length)} with warnings</Badge>
                      )}
                    </div>
                  }
                />

                {result.ignoredColumns.length > 0 && (
                  <p className="mb-4 text-sm text-slate-400">
                    Ignored columns this app doesn&apos;t use: {result.ignoredColumns.join(", ")}.
                  </p>
                )}

                {result.errors.length > 0 && (
                  <div className="mb-5">
                    <Alert
                      tone="error"
                      title={`${formatInt(result.errors.length)} row${result.errors.length === 1 ? "" : "s"} will be skipped`}
                    >
                      Fix these in your file and upload again, or import the valid rows now.
                      <ul className="mt-2 max-h-56 space-y-1 overflow-y-auto pr-1">
                        {result.errors.slice(0, MAX_LISTED_ISSUES).map((e) => (
                          <li key={`${e.row}-${e.message}`}>
                            <span className="font-medium">Row {e.row}:</span> {e.message}
                          </li>
                        ))}
                      </ul>
                      {result.errors.length > MAX_LISTED_ISSUES && (
                        <p className="mt-2 opacity-80">
                          …and {formatInt(result.errors.length - MAX_LISTED_ISSUES)} more.
                        </p>
                      )}
                    </Alert>
                  </div>
                )}

                {result.warnings.length > 0 && (
                  <details className="mb-5 rounded-lg border border-amber-500/25 bg-amber-500/[0.06] p-4 text-sm text-amber-200">
                    <summary className="cursor-pointer font-medium">
                      {formatInt(result.warnings.length)} row{result.warnings.length === 1 ? "" : "s"} imported with warnings
                    </summary>
                    <ul className="mt-3 max-h-48 space-y-1 overflow-y-auto pr-1 text-[0.8125rem]">
                      {result.warnings.slice(0, MAX_LISTED_ISSUES).map((w) => (
                        <li key={`${w.row}-${w.message}`}>
                          <span className="font-medium">Row {w.row}:</span> {w.message}
                        </li>
                      ))}
                    </ul>
                    {result.warnings.length > MAX_LISTED_ISSUES && (
                      <p className="mt-2 opacity-80">
                        …and {formatInt(result.warnings.length - MAX_LISTED_ISSUES)} more.
                      </p>
                    )}
                  </details>
                )}

                {result.posts.length > 0 && (
                  <>
                    <h3 className="mb-2 text-sm font-medium text-slate-300">
                      Preview (first {Math.min(PREVIEW_ROWS, result.posts.length)} of {formatInt(result.posts.length)})
                    </h3>
                    <div className="overflow-x-auto rounded-lg border border-white/[0.07]">
                      <table className="w-full min-w-[820px] text-sm">
                        <caption className="sr-only">Preview of rows that will be imported</caption>
                        <thead className="bg-navy-800 text-left text-xs text-slate-400">
                          <tr>
                            {["Date", "Platform", "Type", "Caption"].map((h) => (
                              <th key={h} scope="col" className="px-3 py-2 font-medium">{h}</th>
                            ))}
                            {["Likes", "Comments", "Shares", "Reach", "Impressions", "Eng. rate"].map((h) => (
                              <th key={h} scope="col" className="px-3 py-2 text-right font-medium">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/[0.05] tabular-nums">
                          {result.posts.slice(0, PREVIEW_ROWS).map((p) => (
                            <tr key={p.id}>
                              <td className="whitespace-nowrap px-3 py-2 text-slate-300">{p.date}</td>
                              <td className="px-3 py-2 text-slate-300">{p.platform}</td>
                              <td className="px-3 py-2 text-slate-400">{p.contentType}</td>
                              <td className="max-w-xs px-3 py-2 text-slate-200">{truncate(p.caption, 48)}</td>
                              <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.likes)}</td>
                              <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.comments)}</td>
                              <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.shares)}</td>
                              <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.reach)}</td>
                              <td className="px-3 py-2 text-right text-slate-300">{formatInt(p.impressions)}</td>
                              <td className="px-3 py-2 text-right font-medium text-white">
                                {p.reach > 0 ? formatPercent(engagementRate(p)) : "n/a"}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}

                {importable && (
                  <div className="mt-6 border-t border-white/[0.07] pt-5">
                    {canChooseMode ? (
                      <fieldset className="mb-5">
                        <legend className="mb-2 text-sm font-medium text-slate-200">
                          You already have imported data. What should happen?
                        </legend>
                        <div className="space-y-2">
                          {(
                            [
                              ["replace", "Replace my existing data", `Removes the ${formatInt(currentPosts.length)} posts you have now.`],
                              ["append", "Add to my existing data", "Keeps current posts and skips exact duplicates (same date, platform and caption)."],
                            ] as const
                          ).map(([value, label, help]) => (
                            <label
                              key={value}
                              className={cx(
                                "flex cursor-pointer gap-3 rounded-lg border p-3 text-sm",
                                mode === value ? "border-accent-500/60 bg-accent-500/10" : "border-white/10 hover:border-white/20",
                              )}
                            >
                              <input
                                type="radio"
                                name="import-mode"
                                value={value}
                                checked={mode === value}
                                onChange={() => setMode(value)}
                                className="mt-1 accent-[#8b5cf6]"
                              />
                              <span>
                                <span className="block font-medium text-slate-100">{label}</span>
                                <span className="block text-slate-400">{help}</span>
                              </span>
                            </label>
                          ))}
                        </div>
                      </fieldset>
                    ) : (
                      source === "demo" && (
                        <p className="mb-4 text-sm text-slate-400">
                          Importing replaces the demo data. You can bring it back any time from Settings.
                        </p>
                      )
                    )}
                    <div className="flex flex-wrap gap-3">
                      <Button variant="primary" onClick={runImport}>
                        <FileIcon width={18} height={18} />
                        Import {formatInt(result.posts.length)} post{result.posts.length === 1 ? "" : "s"}
                      </Button>
                      <Button variant="ghost" onClick={reset}>Cancel</Button>
                    </div>
                  </div>
                )}

                {!importable && (
                  <div className="mt-6 flex gap-3 border-t border-white/[0.07] pt-5">
                    <Button variant="primary" onClick={() => inputRef.current?.click()}>Choose another file</Button>
                    <Button variant="ghost" onClick={reset}>Clear</Button>
                  </div>
                )}
              </Card>
            )}
            {result.fatalError && (
              <div className="flex gap-3">
                <Button variant="primary" onClick={() => inputRef.current?.click()}>Choose another file</Button>
                <Button variant="ghost" onClick={reset}>Clear</Button>
              </div>
            )}
          </>
        )}

        {/* Format help */}
        <Card>
          <CardHeader
            title="Expected columns"
            description="The first row must be a header. Column order doesn't matter, and extra columns are ignored."
          />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <caption className="sr-only">Columns accepted in the CSV file</caption>
              <thead className="text-left text-xs text-slate-400">
                <tr className="border-b border-white/[0.07]">
                  <th scope="col" className="py-2 pr-4 font-medium">Column</th>
                  <th scope="col" className="py-2 pr-4 font-medium">Needed?</th>
                  <th scope="col" className="py-2 pr-4 font-medium">What goes in it</th>
                  <th scope="col" className="py-2 font-medium">Example</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.05]">
                {COLUMN_HELP.map((c) => (
                  <tr key={c.name}>
                    <th scope="row" className="py-2 pr-4 text-left font-mono text-[0.8125rem] font-medium text-slate-100">{c.name}</th>
                    <td className="py-2 pr-4 text-slate-400">{c.required ? "Required" : "Optional"}</td>
                    <td className="py-2 pr-4 text-slate-300">{c.description}</td>
                    <td className="py-2 font-mono text-[0.8125rem] text-slate-400">{c.example}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-slate-400">
            Empty number cells count as 0 and get a warning. Rows with text or negative numbers where a count belongs are
            skipped, with the row number shown above. If you have {REQUIRED_COLUMNS.length} required columns but different
            names, common alternatives such as <code className="font-mono text-slate-300">network</code> or{" "}
            <code className="font-mono text-slate-300">like_count</code> are recognised automatically.
          </p>
        </Card>
      </div>
    </>
  );
}
