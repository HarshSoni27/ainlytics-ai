"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { platformColor } from "@/components/charts/chartTheme";
import { NoDataState } from "@/components/NoDataState";
import { PostDetailPanel } from "@/components/PostDetailPanel";
import { SearchIcon } from "@/components/icons";
import { Button, Card, CONTROL_CLASS, EmptyState, Field, Skeleton, cx } from "@/components/ui";
import { formatDate, formatInt, formatPercent, truncate } from "@/lib/format";
import { ALL_PLATFORMS, engagementRate, interactionsOf, uniquePlatforms } from "@/lib/metrics";
import type { Post } from "@/lib/types";
import { useAnalyticsData } from "@/lib/useAnalyticsData";

type SortKey = "date" | "engagement" | "reach";
type SortDir = "desc" | "asc";

const PAGE_SIZE = 20;

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "date", label: "Date" },
  { value: "engagement", label: "Engagement rate" },
  { value: "reach", label: "Reach" },
];

export default function PostsPage() {
  const { posts, isLoading } = useAnalyticsData();
  const [query, setQuery] = useState("");
  const [platform, setPlatform] = useState(ALL_PLATFORMS);
  const [sortKey, setSortKey] = useState<SortKey>("date");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Post | null>(null);

  const platforms = useMemo(() => uniquePlatforms(posts), [posts]);
  const activePlatform = platforms.includes(platform) ? platform : ALL_PLATFORMS;

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = posts.filter(
      (p) =>
        (activePlatform === ALL_PLATFORMS || p.platform === activePlatform) &&
        (q === "" || p.caption.toLowerCase().includes(q)),
    );
    const dir = sortDir === "desc" ? -1 : 1;
    const value = (p: Post): number =>
      sortKey === "date"
        ? Date.parse(p.date)
        : sortKey === "reach"
          ? p.reach
          : engagementRate(p);
    return filtered
      .map((p) => ({ post: p, rate: engagementRate(p), sortValue: value(p) }))
      .sort((a, b) => (a.sortValue - b.sortValue) * dir || a.post.id.localeCompare(b.post.id));
  }, [posts, query, activePlatform, sortKey, sortDir]);

  const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const visible = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const filtersActive = query !== "" || activePlatform !== ALL_PLATFORMS;

  function clearFilters() {
    setQuery("");
    setPlatform(ALL_PLATFORMS);
    setPage(1);
  }

  return (
    <>
      <PageHeader
        title="Posts"
        description="Search, sort and open any post to see its full numbers."
      />

      {isLoading ? (
        <div className="space-y-4" aria-busy="true" aria-label="Loading posts">
          <Skeleton className="h-24" />
          <Skeleton className="h-96" />
        </div>
      ) : posts.length === 0 ? (
        <NoDataState />
      ) : (
        <div className="space-y-4">
          <Card className="!p-4">
            <div className="flex flex-wrap items-end gap-3">
              <Field label="Search captions" htmlFor="post-search" className="min-w-56 flex-1">
                <div className="relative">
                  <SearchIcon
                    width={16}
                    height={16}
                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"
                  />
                  <input
                    id="post-search"
                    type="search"
                    value={query}
                    onChange={(e) => {
                      setQuery(e.target.value);
                      setPage(1);
                    }}
                    placeholder="Search by caption text"
                    className={cx(CONTROL_CLASS, "w-full pl-9")}
                  />
                </div>
              </Field>

              <Field label="Platform" htmlFor="post-platform">
                <select
                  id="post-platform"
                  value={activePlatform}
                  onChange={(e) => {
                    setPlatform(e.target.value);
                    setPage(1);
                  }}
                  className={cx(CONTROL_CLASS, "min-w-40")}
                >
                  <option value={ALL_PLATFORMS}>All platforms</option>
                  {platforms.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </Field>

              <Field label="Sort by" htmlFor="post-sort">
                <select
                  id="post-sort"
                  value={sortKey}
                  onChange={(e) => {
                    setSortKey(e.target.value as SortKey);
                    setPage(1);
                  }}
                  className={cx(CONTROL_CLASS, "min-w-44")}
                >
                  {SORT_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </Field>

              <Field label="Order" htmlFor="post-order">
                <select
                  id="post-order"
                  value={sortDir}
                  onChange={(e) => {
                    setSortDir(e.target.value as SortDir);
                    setPage(1);
                  }}
                  className={CONTROL_CLASS}
                >
                  <option value="desc">{sortKey === "date" ? "Newest first" : "Highest first"}</option>
                  <option value="asc">{sortKey === "date" ? "Oldest first" : "Lowest first"}</option>
                </select>
              </Field>

              {filtersActive && (
                <Button variant="ghost" className="h-10" onClick={clearFilters}>
                  Clear filters
                </Button>
              )}
            </div>
          </Card>

          <p className="text-sm text-slate-400" aria-live="polite">
            Showing {formatInt(rows.length)} of {formatInt(posts.length)} posts
          </p>

          {rows.length === 0 ? (
            <EmptyState
              title="No posts match your search"
              actions={<Button onClick={clearFilters}>Clear filters</Button>}
            >
              Check the spelling, or try a different platform.
            </EmptyState>
          ) : (
            <Card className="!p-0">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[760px] text-sm">
                  <caption className="sr-only">All posts</caption>
                  <thead className="text-left text-xs text-slate-400">
                    <tr className="border-b border-white/[0.07]">
                      <th scope="col" className="px-4 py-3 font-medium">Date</th>
                      <th scope="col" className="px-4 py-3 font-medium">Platform</th>
                      <th scope="col" className="px-4 py-3 font-medium">Caption</th>
                      <th scope="col" className="px-4 py-3 text-right font-medium">Reach</th>
                      <th scope="col" className="px-4 py-3 text-right font-medium">Interactions</th>
                      <th scope="col" className="px-4 py-3 text-right font-medium">Engagement</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.05] tabular-nums">
                    {visible.map(({ post, rate }) => (
                      <tr
                        key={post.id}
                        onClick={() => setSelected(post)}
                        className="cursor-pointer transition-colors hover:bg-white/[0.03]"
                      >
                        <td className="whitespace-nowrap px-4 py-3 text-slate-300">{formatDate(post.date)}</td>
                        <td className="px-4 py-3 text-slate-300">
                          <span className="inline-flex items-center gap-2">
                            <span className="h-2 w-2 rounded-sm" style={{ background: platformColor(post.platform) }} />
                            {post.platform}
                          </span>
                        </td>
                        <td className="max-w-sm px-4 py-3">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelected(post);
                            }}
                            className="block w-full text-left text-slate-100 hover:text-accent-300"
                          >
                            {truncate(post.caption, 90)}
                          </button>
                        </td>
                        <td className="px-4 py-3 text-right text-slate-300">{formatInt(post.reach)}</td>
                        <td className="px-4 py-3 text-right text-slate-300">{formatInt(interactionsOf(post))}</td>
                        <td className="px-4 py-3 text-right font-semibold text-white">
                          {post.reach > 0 ? formatPercent(rate) : <span className="font-normal text-slate-500">n/a</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {pageCount > 1 && (
                <nav
                  aria-label="Pagination"
                  className="flex items-center justify-between gap-3 border-t border-white/[0.07] px-4 py-3"
                >
                  <Button disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)}>
                    Previous
                  </Button>
                  <span className="text-sm text-slate-400">
                    Page {currentPage} of {pageCount}
                  </span>
                  <Button disabled={currentPage === pageCount} onClick={() => setPage(currentPage + 1)}>
                    Next
                  </Button>
                </nav>
              )}
            </Card>
          )}
        </div>
      )}

      <PostDetailPanel post={selected} allPosts={posts} onClose={() => setSelected(null)} />
    </>
  );
}
