"use client";

import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Alert, Badge, Button, Card, CardHeader, ConfirmDialog } from "@/components/ui";
import { formatDate, formatInt } from "@/lib/format";
import { dateRange } from "@/lib/metrics";
import { useAnalyticsData } from "@/lib/useAnalyticsData";

type Pending = "reset" | "clear" | null;

export default function SettingsPage() {
  const { posts, source, isLoading, updatedAt, resetDemo, clearAll } = useAnalyticsData();
  const [pending, setPending] = useState<Pending>(null);
  const [message, setMessage] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  const range = dateRange(posts);

  function confirm() {
    const action = pending;
    setPending(null);
    if (action === "reset") {
      const r = resetDemo();
      setMessage(
        r.ok
          ? { tone: "success", text: "Demo data restored. Your imported data was replaced." }
          : { tone: "error", text: r.error ?? "Couldn't reset the data." },
      );
    } else if (action === "clear") {
      const r = clearAll();
      setMessage(
        r.ok
          ? { tone: "success", text: "All data cleared. Upload a CSV or reset the demo data to continue." }
          : { tone: "error", text: r.error ?? "Couldn't clear the data." },
      );
    }
  }

  return (
    <>
      <PageHeader title="Settings" description="Manage the data stored in this browser and see how metrics are calculated." />

      <div className="max-w-3xl space-y-6">
        {message && (
          <Alert tone={message.tone} onDismiss={() => setMessage(null)}>
            {message.text}
          </Alert>
        )}

        <Card>
          <CardHeader title="Your data" description="Everything is stored in this browser only. Nothing is uploaded to a server." />
          <dl className="grid gap-4 text-sm sm:grid-cols-3">
            <div>
              <dt className="text-slate-400">Source</dt>
              <dd className="mt-1">
                {isLoading ? (
                  "Loading…"
                ) : source === "demo" ? (
                  <Badge tone="accent">Demo data</Badge>
                ) : source === "imported" ? (
                  <Badge tone="good">Imported CSV</Badge>
                ) : (
                  <Badge tone="warn">Empty</Badge>
                )}
              </dd>
            </div>
            <div>
              <dt className="text-slate-400">Posts</dt>
              <dd className="mt-1 font-medium text-slate-100">{isLoading ? "…" : formatInt(posts.length)}</dd>
            </div>
            <div>
              <dt className="text-slate-400">Date range</dt>
              <dd className="mt-1 font-medium text-slate-100">
                {range ? `${formatDate(range.min)} – ${formatDate(range.max)}` : "–"}
              </dd>
            </div>
          </dl>
          {updatedAt && (
            <p className="mt-4 text-xs text-slate-500">Last changed {new Date(updatedAt).toLocaleString()}</p>
          )}

          <div className="mt-6 space-y-4 border-t border-white/[0.07] pt-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="max-w-md">
                <h3 className="text-sm font-medium text-slate-100">Reset demo data</h3>
                <p className="mt-0.5 text-sm text-slate-400">
                  Replace everything with the sample coffee-brand dataset.
                </p>
              </div>
              <Button onClick={() => (source === "demo" ? confirmNow("reset") : setPending("reset"))} disabled={isLoading}>
                Reset demo data
              </Button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="max-w-md">
                <h3 className="text-sm font-medium text-slate-100">Clear imported data</h3>
                <p className="mt-0.5 text-sm text-slate-400">
                  Delete every post so you can start from a blank dashboard.
                </p>
              </div>
              <Button variant="danger" onClick={() => setPending("clear")} disabled={isLoading || posts.length === 0}>
                Clear all data
              </Button>
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader title="How engagement rate is calculated" />
          <p className="rounded-lg border border-accent-500/25 bg-accent-500/[0.07] px-4 py-3 font-mono text-sm text-slate-100">
            engagement rate = (likes + comments + shares) ÷ reach × 100
          </p>
          <div className="mt-4 space-y-3 text-sm leading-relaxed text-slate-300">
            <p>
              Example: a post with 100 likes, 20 comments and 10 shares that reached 1,000 people has an
              engagement rate of (100 + 20 + 10) ÷ 1,000 × 100 = <strong className="text-white">13%</strong>.
            </p>
            <p>
              <strong className="text-slate-100">Averages</strong> are the mean of each post&apos;s own rate, so
              a post that reached 500 people counts as much as one that reached 50,000.
            </p>
            <p>
              <strong className="text-slate-100">Zero reach:</strong> a rate can&apos;t be calculated, so the post
              shows &ldquo;n/a&rdquo; and is left out of averages instead of counting as 0%. Its likes, comments
              and shares still count in the totals.
            </p>
            <p>
              Rates above 100% are possible when interactions exceed reach (for example, repeat likes from
              people who were reached earlier). The upload page warns you about these rows.
            </p>
          </div>
        </Card>

        <Card>
          <CardHeader title="About Ainlytics AI" />
          <p className="text-sm leading-relaxed text-slate-300">
            A portfolio MVP. All calculations run in your browser with no account, database or paid service.
            Insights are rule-based statistics unless the site owner turns on the optional, access-code
            protected AI panel; see the README.
          </p>
        </Card>
      </div>

      <ConfirmDialog
        open={pending === "reset"}
        title="Reset to demo data?"
        confirmLabel="Reset demo data"
        destructive
        onConfirm={confirm}
        onCancel={() => setPending(null)}
      >
        {posts.length > 0
          ? `This replaces your ${formatInt(posts.length)} imported posts with the demo dataset. You can't undo it, but you can upload your CSV again.`
          : "This loads the demo dataset."}
      </ConfirmDialog>

      <ConfirmDialog
        open={pending === "clear"}
        title="Clear all data?"
        confirmLabel="Clear all data"
        destructive
        onConfirm={confirm}
        onCancel={() => setPending(null)}
      >
        This permanently deletes all {formatInt(posts.length)} posts from this browser. You can&apos;t undo it.
      </ConfirmDialog>
    </>
  );

  function confirmNow(action: "reset") {
    // Demo data is already loaded, so resetting loses nothing; skip the dialog.
    if (action === "reset") {
      const r = resetDemo();
      setMessage(
        r.ok
          ? { tone: "success", text: "Demo data restored." }
          : { tone: "error", text: r.error ?? "Couldn't reset the data." },
      );
    }
  }
}
