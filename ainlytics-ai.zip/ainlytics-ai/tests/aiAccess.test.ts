import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { codeMatches, createRateLimiter, getAiStatus, isSameOrigin } from "../src/lib/aiAccess";

describe("AI access rules", () => {
  it("is off by default and when nothing is configured", () => {
    assert.deepEqual(getAiStatus({}), { enabled: false, requiresCode: false });
    assert.equal(getAiStatus({ NODE_ENV: "production" }).enabled, false);
  });

  it("a key alone never switches AI on", () => {
    assert.equal(getAiStatus({ ANTHROPIC_API_KEY: "placeholder" }).enabled, false);
    assert.equal(getAiStatus({ ANTHROPIC_API_KEY: "placeholder", ENABLE_AI_INSIGHTS: "yes" }).enabled, false);
    assert.equal(getAiStatus({ ANTHROPIC_API_KEY: "placeholder", ENABLE_AI_INSIGHTS: "false" }).enabled, false);
  });

  it("opt-in without a key stays off", () => {
    assert.equal(getAiStatus({ ENABLE_AI_INSIGHTS: "true" }).enabled, false);
    assert.equal(getAiStatus({ ENABLE_AI_INSIGHTS: "true", ANTHROPIC_API_KEY: "   " }).enabled, false);
  });

  it("works without a code in development", () => {
    const s = getAiStatus({ ANTHROPIC_API_KEY: "k", ENABLE_AI_INSIGHTS: "true", NODE_ENV: "development" });
    assert.deepEqual(s, { enabled: true, requiresCode: false });
  });

  it("refuses to run in production without an access code", () => {
    const s = getAiStatus({ ANTHROPIC_API_KEY: "k", ENABLE_AI_INSIGHTS: "true", NODE_ENV: "production" });
    assert.equal(s.enabled, false);
    const blank = getAiStatus({ ANTHROPIC_API_KEY: "k", ENABLE_AI_INSIGHTS: "true", NODE_ENV: "production", AI_ACCESS_CODE: "  " });
    assert.equal(blank.enabled, false);
  });

  it("runs in production only with key + opt-in + code, and then requires the code", () => {
    const s = getAiStatus({
      ANTHROPIC_API_KEY: "k",
      ENABLE_AI_INSIGHTS: "TRUE",
      NODE_ENV: "production",
      AI_ACCESS_CODE: "correct horse",
    });
    assert.deepEqual(s, { enabled: true, requiresCode: true });
  });

  it("compares access codes strictly", () => {
    assert.equal(codeMatches("correct horse", "correct horse"), true);
    assert.equal(codeMatches("correct horse ", "correct horse"), false);
    assert.equal(codeMatches("Correct horse", "correct horse"), false);
    assert.equal(codeMatches("", "correct horse"), false);
    assert.equal(codeMatches(null, "correct horse"), false);
    assert.equal(codeMatches("anything", ""), true, "no code configured means nothing to check");
  });

  it("allows only same-origin browser requests", () => {
    assert.equal(isSameOrigin("https://my-app.vercel.app", "my-app.vercel.app"), true);
    assert.equal(isSameOrigin("https://evil.example", "my-app.vercel.app"), false);
    assert.equal(isSameOrigin("not a url", "my-app.vercel.app"), false);
    assert.equal(isSameOrigin("https://my-app.vercel.app", null), false);
    assert.equal(isSameOrigin(null, "my-app.vercel.app"), true);
  });
});

describe("rate limiter", () => {
  it("limits each caller within a window, then resets", () => {
    let t = 1_000_000;
    const check = createRateLimiter({ perKey: 3, windowMs: 60_000, globalCap: 100, now: () => t });
    assert.ok(check("a").ok && check("a").ok && check("a").ok);
    const blocked = check("a");
    assert.equal(blocked.ok, false);
    assert.ok(blocked.retryAfterSeconds > 0 && blocked.retryAfterSeconds <= 60);
    assert.ok(check("b").ok, "other callers are unaffected");
    t += 60_001;
    assert.ok(check("a").ok, "window reset");
  });

  it("enforces a site-wide daily cap", () => {
    let t = 0;
    const check = createRateLimiter({ perKey: 100, windowMs: 60_000, globalCap: 5, now: () => t });
    for (let i = 0; i < 5; i++) assert.ok(check(`ip${i}`).ok);
    assert.equal(check("new").ok, false);
    t += 86_400_001;
    assert.ok(check("new").ok, "cap resets after 24h");
  });

  it("does not let blocked requests grow the map without bound", () => {
    let t = 0;
    const check = createRateLimiter({ perKey: 1, windowMs: 1_000, globalCap: 1_000_000, now: () => t });
    for (let i = 0; i < 2_000; i++) {
      t += 2_000;
      check(`ip${i}`);
    }
    assert.ok(check("fresh").ok);
  });
});
