import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, it } from "node:test";

import { mergePosts, parseCount, parseCsvText, parseDate } from "../src/lib/csv";
import { DEMO_END, DEMO_START, generateDemoPosts } from "../src/lib/demoData";
import { analyzeLocally, buildAiPayload } from "../src/lib/insights";
import {
  buildPlatformStats,
  buildTrend,
  engagementRate,
  filterPosts,
  summarize,
  averageEngagementRate,
} from "../src/lib/metrics";
import type { Post } from "../src/lib/types";

const publicFile = (name: string) =>
  readFileSync(join(process.cwd(), "public", name), "utf8");

function makePost(overrides: Partial<Post> = {}): Post {
  return {
    id: "t1",
    date: "2026-11-01",
    platform: "Instagram",
    caption: "Test",
    contentType: "Image",
    likes: 100,
    comments: 20,
    shares: 10,
    reach: 1000,
    impressions: 1500,
    ...overrides,
  };
}

describe("engagement formula", () => {
  it("computes (likes + comments + shares) / reach * 100", () => {
    assert.equal(engagementRate(makePost()), 13);
    assert.equal(engagementRate(makePost({ likes: 1, comments: 0, shares: 0, reach: 8 })), 12.5);
  });

  it("returns 0 (not NaN or Infinity) when reach is zero", () => {
    const rate = engagementRate(makePost({ reach: 0 }));
    assert.equal(rate, 0);
    assert.ok(Number.isFinite(rate));
  });

  it("excludes zero-reach posts from the average instead of counting them as 0%", () => {
    const posts = [
      makePost({ id: "a" }), // 13%
      makePost({ id: "b", likes: 0, comments: 0, shares: 0, reach: 1000 }), // 0%
      makePost({ id: "c", reach: 0 }), // undefined -> ignored
    ];
    assert.equal(averageEngagementRate(posts), 6.5);
    assert.equal(summarize(posts).zeroReachPosts, 1);
  });

  it("handles an empty dataset", () => {
    const s = summarize([]);
    assert.equal(s.totalPosts, 0);
    assert.equal(s.avgEngagementRate, 0);
    assert.deepEqual(buildTrend([]).points, []);
    assert.deepEqual(buildPlatformStats([]), []);
  });
});

describe("demo data", () => {
  const demo = generateDemoPosts();

  it("is deterministic", () => {
    assert.deepEqual(generateDemoPosts(), demo);
  });

  it("is realistic and valid", () => {
    assert.ok(demo.length >= 90 && demo.length <= 160, `got ${demo.length} posts`);
    assert.equal(new Set(demo.map((p) => p.id)).size, demo.length, "ids are unique");
    assert.equal(new Set(demo.map((p) => p.platform)).size, 5);
    for (const p of demo) {
      assert.ok(p.date >= DEMO_START && p.date <= DEMO_END);
      assert.ok(p.reach > 0 && p.impressions >= p.reach);
      for (const n of [p.likes, p.comments, p.shares]) {
        assert.ok(Number.isInteger(n) && n >= 0);
      }
      assert.ok(engagementRate(p) < 100);
    }
  });
});

describe("dashboard calculations stay consistent", () => {
  const demo = generateDemoPosts();
  const s = summarize(demo);

  it("totals equal the sum of the parts", () => {
    assert.equal(s.totalPosts, demo.length);
    assert.equal(s.totalLikes, demo.reduce((a, p) => a + p.likes, 0));
    assert.equal(s.totalInteractions, s.totalLikes + s.totalComments + s.totalShares);
  });

  it("platform breakdown covers every post and every interaction", () => {
    const stats = buildPlatformStats(demo);
    assert.equal(stats.reduce((a, p) => a + p.posts, 0), s.totalPosts);
    assert.equal(stats.reduce((a, p) => a + p.interactions, 0), s.totalInteractions);
    assert.equal(stats.reduce((a, p) => a + p.reach, 0), s.totalReach);
  });

  it("trend buckets cover every post and every interaction", () => {
    const { points } = buildTrend(demo);
    assert.equal(points.reduce((a, p) => a + p.posts, 0), s.totalPosts);
    assert.equal(points.reduce((a, p) => a + p.interactions, 0), s.totalInteractions);
    assert.equal(points.reduce((a, p) => a + p.reach, 0), s.totalReach);
  });

  it("filters by platform and date range", () => {
    const ig = filterPosts(demo, { platform: "Instagram", from: "", to: "" });
    assert.ok(ig.length > 0 && ig.every((p) => p.platform === "Instagram"));

    const nov = filterPosts(demo, { platform: "all", from: "2026-11-01", to: "2026-11-10" });
    assert.ok(nov.length > 0);
    assert.ok(nov.every((p) => p.date >= "2026-11-01" && p.date <= "2026-11-10"));

    const none = filterPosts(demo, { platform: "all", from: "2030-01-01", to: "" });
    assert.equal(none.length, 0);
    assert.equal(summarize(none).avgEngagementRate, 0);
  });

  it("uses daily buckets for short ranges and weekly buckets for long ones", () => {
    const short = filterPosts(demo, { platform: "all", from: "2026-11-01", to: "2026-11-15" });
    assert.equal(buildTrend(short).granularity, "day");
    assert.equal(buildTrend(demo).granularity, "week");
  });
});

describe("CSV parsing and validation", () => {
  const header = "date,platform,caption,likes,comments,shares,reach,impressions";

  it("imports the shipped sample file without errors", () => {
    const r = parseCsvText(publicFile("sample-posts.csv"));
    assert.equal(r.fatalError, null);
    assert.equal(r.errors.length, 0);
    assert.equal(r.posts.length, 46);
  });

  it("reports missing required columns", () => {
    const r = parseCsvText("date,platform,caption\n2026-11-01,X,hi");
    assert.ok(r.fatalError?.includes("likes"));
    assert.ok(r.fatalError?.includes("impressions"));
    assert.equal(r.posts.length, 0);
  });

  it("rejects empty files and files with no data rows", () => {
    assert.ok(parseCsvText("").fatalError);
    assert.ok(parseCsvText("   \n  ").fatalError);
    assert.ok(parseCsvText(`${header}\n`).fatalError?.includes("no data rows"));
  });

  it("skips bad rows with row numbers and clear messages, and keeps good ones", () => {
    const r = parseCsvText(publicFile("sample-posts-with-errors.csv"));
    assert.equal(r.fatalError, null);
    assert.equal(r.totalRows, 12);
    assert.equal(r.posts.length, 6, "6 importable rows (valid + warning rows)");
    assert.equal(r.errors.length, 6);

    const byRow = new Map(r.errors.map((e) => [e.row, e.message]));
    assert.match(byRow.get(8) ?? "", /date/);
    assert.match(byRow.get(9) ?? "", /date/); // 2026-02-31
    assert.match(byRow.get(10) ?? "", /platform/);
    assert.match(byRow.get(11) ?? "", /likes.*whole number/);
    assert.match(byRow.get(12) ?? "", /negative/);
    assert.match(byRow.get(13) ?? "", /comments.*whole number/);
  });

  it("handles missing values and zero reach safely", () => {
    const r = parseCsvText(publicFile("sample-posts-with-errors.csv"));
    const zeroReach = r.posts.find((p) => p.caption.startsWith("Zero reach"));
    assert.ok(zeroReach);
    assert.equal(engagementRate(zeroReach), 0);

    const noCaption = r.posts.find((p) => p.platform === "X");
    assert.equal(noCaption?.caption, "(no caption)");

    const missingImpressions = r.posts.find((p) => p.caption.startsWith("Missing impressions"));
    assert.equal(missingImpressions?.impressions, 0);

    const warnedRows = new Set(r.warnings.map((w) => w.row));
    for (const row of [4, 5, 6, 7]) assert.ok(warnedRows.has(row), `row ${row} should warn`);
  });

  it("recalculates metrics from the imported data (nothing hardcoded)", () => {
    const csv = [
      header,
      "2026-11-01,Instagram,A,10,5,5,200,300",
      "2026-11-02,LinkedIn,B,30,10,0,400,500",
    ].join("\n");
    const r = parseCsvText(csv);
    const s = summarize(r.posts);
    assert.equal(s.totalPosts, 2);
    assert.equal(s.totalLikes, 40);
    assert.equal(s.totalReach, 600);
    assert.equal(s.totalImpressions, 800);
    // (20/200*100 + 40/400*100) / 2 = 10
    assert.equal(s.avgEngagementRate, 10);
  });

  it("accepts header aliases, BOM, blank lines, quoted commas and extra columns", () => {
    const csv =
      "﻿Post Date,Network,Text,Like Count,Comments,Shares,Reach,Impressions,Notes\n" +
      '2026-11-01,twitter,"Hello, world",1,2,3,100,150,ignore me\n' +
      "\n" +
      "2026/11/02,IG,Second,4,5,6,200,250,\n";
    const r = parseCsvText(csv);
    assert.equal(r.fatalError, null);
    assert.equal(r.errors.length, 0);
    assert.equal(r.posts.length, 2);
    assert.equal(r.posts[0].platform, "X");
    assert.equal(r.posts[0].caption, "Hello, world");
    assert.equal(r.posts[1].platform, "Instagram");
    assert.equal(r.posts[1].date, "2026-11-02");
    assert.deepEqual(r.ignoredColumns, ["notes"]);
  });

  it("parses numbers and dates strictly", () => {
    assert.deepEqual(parseCount("1,234", "likes"), { kind: "ok", value: 1234 });
    assert.deepEqual(parseCount("120.0", "likes"), { kind: "ok", value: 120 });
    assert.deepEqual(parseCount("", "likes"), { kind: "missing" });
    for (const bad of ["abc", "-1", "1.5", "1e3", "0x10", "Infinity", "12%"]) {
      assert.equal(parseCount(bad, "likes").kind, "error", `"${bad}" should be rejected`);
    }
    assert.equal(parseDate("2026-11-20"), "2026-11-20");
    assert.equal(parseDate("2026-11-20T10:30:00Z"), "2026-11-20");
    assert.equal(parseDate("2026-02-31"), null);
    assert.equal(parseDate("20/11/2026"), null);
    assert.equal(parseDate("11/20/2026"), null);
  });

  it("does not let formula-like captions break anything", () => {
    const r = parseCsvText(`${header}\n2026-11-01,X,=SUM(A1:A9),1,1,1,100,100`);
    assert.equal(r.posts.length, 1);
    assert.equal(r.posts[0].caption, "=SUM(A1:A9)");
  });

  it("merges without creating duplicates", () => {
    const a = [makePost({ id: "1" })];
    const b = [makePost({ id: "2" }), makePost({ id: "3", date: "2026-11-02" })];
    const { merged, added, duplicates } = mergePosts(a, b);
    assert.equal(added, 1);
    assert.equal(duplicates, 1);
    assert.equal(merged.length, 2);
  });
});

describe("local insights", () => {
  const demo = generateDemoPosts();
  const insights = analyzeLocally(demo);

  it("reports best and worst posts in the right order", () => {
    assert.equal(insights.best.length, 3);
    assert.equal(insights.worst.length, 3);
    assert.ok(insights.best[0].rate >= insights.best[1].rate);
    assert.ok(insights.worst[0].rate <= insights.worst[1].rate);
    assert.ok(insights.best[0].rate > insights.worst[0].rate);
    const bestIds = new Set(insights.best.map((r) => r.post.id));
    assert.ok(insights.worst.every((r) => !bestIds.has(r.post.id)));
  });

  it("produces patterns, suggestions and exactly three post ideas", () => {
    assert.ok(insights.hasEnoughData);
    assert.ok(insights.patterns.length > 0);
    assert.ok(insights.suggestions.length > 0 && insights.suggestions.length <= 6);
    assert.equal(insights.ideas.length, 3);
    for (const idea of insights.ideas) {
      assert.ok(idea.title && idea.platform && idea.format && idea.caption && idea.rationale);
    }
  });

  it("only suggests formats that exist on the suggested platform", () => {
    for (const idea of insights.ideas) {
      const formatsOnPlatform = new Set(
        demo.filter((p) => p.platform === idea.platform).map((p) => p.contentType),
      );
      assert.ok(
        formatsOnPlatform.has(idea.format),
        `${idea.format} is not used on ${idea.platform} (has ${[...formatsOnPlatform].join(", ")})`,
      );
    }
  });

  it("never turns filler words into themes or interpolates them into ideas", () => {
    for (const word of insights.themeWords) {
      assert.ok(word.length >= 4, `"${word}" is too short to be a theme`);
      assert.ok(!["see", "it's", "swipe", "here"].includes(word));
    }
    for (const idea of insights.ideas) {
      assert.ok(!/rather see more of: see/i.test(idea.caption));
    }
  });

  it("never emits NaN or Infinity", () => {
    const text = JSON.stringify(insights);
    assert.ok(!/NaN|Infinity|undefined/.test(text));
  });

  it("degrades gracefully with little or no data", () => {
    const empty = analyzeLocally([]);
    assert.equal(empty.hasEnoughData, false);
    assert.equal(empty.ideas.length, 0);

    const tiny = analyzeLocally([makePost({ id: "a" }), makePost({ id: "b", reach: 0 })]);
    assert.equal(tiny.hasEnoughData, false);
    assert.equal(tiny.best.length, 1);
  });

  it("works when every post has zero reach", () => {
    const zero = analyzeLocally(demo.slice(0, 20).map((p) => ({ ...p, reach: 0 })));
    assert.equal(zero.hasEnoughData, false);
    assert.ok(!/NaN|Infinity/.test(JSON.stringify(zero)));
  });

  it("builds a compact payload for the optional AI route", () => {
    const payload = buildAiPayload(demo);
    assert.ok(payload);
    assert.equal(payload.totals.posts, demo.length);
    assert.equal(payload.topPosts.length, 5);
    assert.ok(payload.topPosts.every((p) => p.caption.length <= 140));
    assert.ok(JSON.stringify(payload).length < 20_000);
    assert.equal(buildAiPayload([]), null);
  });
});
