# Ainlytics AI

A social media analytics dashboard. Upload a CSV of post analytics and get engagement metrics, charts, a searchable
posts table and data-driven insights. Everything runs in the browser: no database, no login, no paid service.

> **Live demo:** _add your Vercel URL here after you deploy (see [DEPLOYMENT.md](./DEPLOYMENT.md))._

![Dashboard](./docs/screenshots/dashboard.png)

<table>
  <tr>
    <td><img src="./docs/screenshots/upload-validation.png" alt="CSV upload with row-level validation errors"></td>
    <td><img src="./docs/screenshots/insights.png" alt="Local insights page"></td>
  </tr>
  <tr>
    <td><img src="./docs/screenshots/post-detail.png" alt="Post detail panel"></td>
    <td><img src="./docs/screenshots/mobile-dashboard.png" alt="Dashboard on a phone" width="260"></td>
  </tr>
</table>

## Features

- **Dashboard:** totals for posts, likes, comments, shares, reach and impressions; average engagement rate; engagement
  trend and platform charts (each with a table view); top posts; date and platform filters.
- **CSV upload:** drag and drop, required-column and number validation, row-level error messages, preview before
  import, replace or append, duplicate detection. Handles blank values, zero reach, semicolon-delimited and
  Excel-style files. Up to 5 MB / 5,000 rows.
- **Posts:** caption search, platform filter, sort by date / reach / engagement, post detail panel with the formula
  worked out for that post.
- **Insights:** best and worst posts, engagement patterns (platform, format, weekday, hashtags, question captions,
  caption length, trend), improvement suggestions and three post ideas. These are **rule-based statistics and are
  labelled as such, never presented as AI output.**
- **Optional AI panel:** off by default, server-side only, access-code protected in production (see below).
- **Settings:** reset demo data, clear all data (with confirmation), formula explanation.
- **Persistence:** data stays in your browser (`localStorage`) across refreshes; corrupt data is detected and reset.

**Engagement rate = (likes + comments + shares) ÷ reach × 100.** Averages are the mean of each post's own rate. Posts
with zero reach have no defined rate: they show "n/a" and are left out of averages (but still count in totals).

## Tech stack

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4 · Recharts · PapaParse · Node's built-in test runner
(via `tsx`). Hosted on Vercel's free tier in the deployment guide. No database or authentication.

## Getting started

Requires [Node.js](https://nodejs.org) **20.9 or newer**.

```bash
npm install
npm run dev
```

Open <http://localhost:3000>. The first launch loads ~109 demo posts for a fictional coffee brand.

| Command | What it does |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` / `npm start` | Production build / run it |
| `npm run typecheck` | TypeScript check |
| `npm run lint` | ESLint |
| `npm test` | 40 unit tests (formula, CSV validation, insights, AI access rules) |
| `npm run generate:sample` | Regenerate the sample CSVs in `public/` |

## CSV format

First row must be a header. Column order and letter case don't matter; extra columns are ignored.

| Column | Required | Notes |
| --- | --- | --- |
| `date` | yes | `YYYY-MM-DD` (also `YYYY/MM/DD`, or with a time) |
| `platform` | yes | Instagram, Facebook, LinkedIn, X/Twitter, TikTok, YouTube… (common spellings are normalised) |
| `caption` | yes | May be blank |
| `likes`, `comments`, `shares`, `reach`, `impressions` | yes | Whole numbers ≥ 0. Blank counts as 0 with a warning |
| `content_type` | no | Image, Video, Reel… used by insights |

Try [`public/sample-posts.csv`](./public/sample-posts.csv) (valid) and
[`public/sample-posts-with-errors.csv`](./public/sample-posts-with-errors.csv) (deliberate mistakes).

## Architecture

```
src/
  app/            pages (dashboard, upload, posts, insights, settings) + api/insights/route.ts
  components/     AppShell, Filters, MetricCard, TopPostsTable, PostDetailPanel, ui.tsx, charts/
  lib/
    metrics.ts    THE engagement formula + all aggregation, filtering and chart data
    csv.ts        parsing, validation, merging (pure functions)
    insights.ts   local rule-based analysis + the compact payload for the optional AI call
    aiAccess.ts   rules for who may use the AI endpoint, plus the rate limiter
    store.ts      localStorage-backed store (useSyncExternalStore, hydration-safe)
    demoData.ts   seeded generator, identical demo data on every launch
tests/            unit tests
docs/screenshots  images used in this README
```

Every number on every page comes from `src/lib/metrics.ts`, and tests check that totals, platform breakdowns and trend
buckets add up to the same figures.

## Optional AI insights and security

The app is fully functional with **no environment variables**. For a public portfolio site, leave them unset.

The AI endpoint (`/api/insights`) runs only on the server and is OFF unless **all** of these are true:

| Variable | Purpose |
| --- | --- |
| `ANTHROPIC_API_KEY` | Your API key. Server only; never sent to browsers |
| `ENABLE_AI_INSIGHTS=true` | Explicit opt-in. A key alone does not turn AI on |
| `AI_ACCESS_CODE` | **Required in production.** Visitors must enter this code before the endpoint runs |

Also built in: same-origin check, rate limiting (5 requests / 10 min per caller, 200 / day site-wide, best effort on
serverless hosts), request size limit, upstream error bodies never forwarded, and response headers
(`X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`). Only a compact summary (totals, platform
averages, up to 10 truncated captions) is ever sent to the AI provider, not your whole file.

Local setup: `cp .env.example .env.local`, fill it in, restart `npm run dev`. `.env*` files are git-ignored (only
`.env.example` is committed). **Never prefix these variables with `NEXT_PUBLIC_`.**

## Testing

See [TESTING.md](./TESTING.md) for results and a manual checklist.

## Deployment

See [DEPLOYMENT.md](./DEPLOYMENT.md) for step-by-step GitHub and Vercel instructions and a live-site checklist.

## Screenshots

The images in `docs/screenshots/` are referenced by this README. To replace them with your own, run the app with the
demo data, take screenshots at about 1440 px wide in your browser's responsive mode, and save them over the existing
files with the same names. A dashboard at the top and two or three feature shots (upload validation, insights, post
detail) is enough for a portfolio.

## Known limitations

- Data lives only in the browser that imported it (about 5 MB of storage). It isn't shared across devices and is lost if
  site data is cleared.
- CSV only: no Excel files or social network API connections. Dates must be `YYYY-MM-DD` style.
- Insights show correlation, not proof, and need at least 5 posts with reach (3+ per group) to find patterns.
- Platforms outside the built-in list share one grey chart colour.
- Rate limiting is in memory, so on serverless hosting it is a speed bump; the access code is the real protection.
- Tested in headless Chromium only. No formal accessibility audit has been done.
- No user accounts, multiple workspaces or data export.

## License

No license file is included. Add one (for example MIT) before inviting others to reuse the code.
