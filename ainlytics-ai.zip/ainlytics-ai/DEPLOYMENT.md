# Deployment guide

Ainlytics AI needs no database and no environment variables, so the default deployment is simple and safe.
Nothing here has been done for you: you create the GitHub repository and the Vercel project yourself.

## 1. Put the code on GitHub

You need a free account at <https://github.com>.

### Option A: no Git or Node needed (upload in the browser)

1. Extract the ZIP on your computer. You should see a folder containing `package.json`, `src`, `public`, `README.md`, etc.
2. On GitHub click **+ → New repository**.
3. Name it `ainlytics-ai`. Choose **Public** (for a portfolio) or **Private**.
4. Leave **Add a README**, **.gitignore** and **license** UNTICKED (the project already has them). Click **Create repository**.
5. On the next page click **uploading an existing file**.
6. Open the extracted folder, select **everything inside it** (all files and folders), and drag them onto the GitHub page.
   Wait for the upload to finish.
7. Scroll down, keep **Commit directly to the main branch**, and click **Commit changes**.
8. Check the file list on GitHub: you should see `src`, `public`, `docs`, `tests`, `package.json`, `package-lock.json`,
   `.gitignore` and `.env.example`. You must **not** see `node_modules` or any `.env.local` file.

If a single upload is refused for having too many files, upload the folders in two batches (e.g. `src` first, then the rest).

### Option B: with Git installed

The ZIP has no Git history, so start one. Replace `YOUR-USERNAME`.

```bash
cd ainlytics-ai
git init
git add .
git status          # check: no node_modules, no .env.local
git commit -m "Ainlytics AI: social media analytics dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ainlytics-ai.git
git push -u origin main
```

Create the empty repository on GitHub first (steps 2 to 4 above). Git will ask you to sign in. If you use the GitHub CLI
you can instead run `gh repo create ainlytics-ai --public --source=. --remote=origin --push`.

If Git says it doesn't know who you are, run `git config --global user.name "Your Name"` and
`git config --global user.email "you@example.com"` once, then commit again.

## 2. Deploy on Vercel (free Hobby plan)

1. Go to <https://vercel.com/signup> and choose **Continue with GitHub**. Approve access.
2. Click **Add New… → Project**.
3. Find `ainlytics-ai` in the list and click **Import**. (If it's missing, click **Adjust GitHub App Permissions** and
   allow that repository.)
4. Vercel detects **Next.js** automatically. Leave **Build Command**, **Output Directory** and **Install Command** as they
   are. Do not add any environment variables.
5. Click **Deploy** and wait about a minute.
6. When it says **Congratulations**, click the preview image or **Visit** to open your site. The address looks like
   `https://ainlytics-ai-xxxx.vercel.app`.
7. Go through the checklist in section 4 on that address.
8. Add the URL to the "Live demo" line in `README.md` (edit the file on GitHub with the pencil icon).

Every later push to `main` redeploys automatically.

## 3. Environment variables (all optional)

For a public portfolio site: **add none.** The app works fully and the AI endpoint stays off.

To enable the optional AI panel, in Vercel open your project → **Settings → Environment Variables** and add all three:

| Name | Value | Notes |
| --- | --- | --- |
| `ANTHROPIC_API_KEY` | your key | Tick **Sensitive** so the value can't be read back |
| `ENABLE_AI_INSIGHTS` | `true` | Explicit opt-in |
| `AI_ACCESS_CODE` | a long random phrase | Required; without it the endpoint refuses to run in production. Tick **Sensitive** |

Then redeploy (**Deployments → ⋯ → Redeploy**), because variables apply only to new deployments.

Rules to keep it safe:

- Never name a variable starting with `NEXT_PUBLIC_`; those are sent to every visitor's browser.
- Never put keys in the code, in GitHub, in README or in screenshots.
- Share the access code only with people you trust (for example a reviewer), not on the public site.
- In your Anthropic console, set a low monthly spend limit for this key. If a key ever leaks, delete it there and create a new one.
- Rate limiting is best effort on Vercel. The access code is what actually protects your quota.

## 4. Verify the live website

Open the real `https://…vercel.app` address (not localhost) and tick each item. Only call it live once these pass.

- [ ] The address loads and shows the dashboard with "Demo data" and 109 posts (average engagement 5.22%)
- [ ] Browser address bar shows a lock (HTTPS) and the tab shows the page title "Ainlytics AI"
- [ ] Platform filter "TikTok" shows 18 posts; "Clear filters" restores 109
- [ ] Charts draw, hovering shows tooltips, **Table** view works
- [ ] **Upload CSV → Download sample CSV** works; uploading it shows a preview, then **Import** gives 46 posts
- [ ] Refresh the page: the imported data is still there
- [ ] `sample-posts-with-errors.csv` shows 6 skipped rows with row numbers
- [ ] **Posts**: search, sort and opening a post detail panel work
- [ ] **AI Insights**: says "Rule-based statistics, not an AI model" and "AI is not set up" (when you added no variables)
- [ ] **Settings**: clearing data asks for confirmation; reset demo data restores 109 posts
- [ ] Open the site on your phone: the menu opens and the page doesn't scroll sideways
- [ ] Open `https://YOUR-ADDRESS/api/insights` in the browser: it must show `{"configured":false,...}` unless you enabled AI on purpose
- [ ] Right-click → View page source and search for `sk-` or `ANTHROPIC`: neither should appear
- [ ] (Only if AI is enabled) the panel asks for the access code and rejects a wrong one

## 5. If something goes wrong

| Symptom | What to do |
| --- | --- |
| Vercel build fails | Open the failed deployment → **Build Logs**. Run `npm run build` locally if you can; the error is usually shown at the end of the log |
| Preview link asks you to log in | Vercel can protect non-production preview URLs. Use the main production domain shown in the project's **Domains** tab |
| Page loads but is unstyled | Redeploy once (**Deployments → ⋯ → Redeploy**, untick "Use existing build cache") |
| Data disappeared | Data is stored per browser and per address. A different browser, device or URL starts with demo data |
| AI panel says "not set up" after adding variables | Check all three exist, spelling is exact, `ENABLE_AI_INSIGHTS` is `true`, and you redeployed |
