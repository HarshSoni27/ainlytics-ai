# Testing

## Results (final code, 2026-11-23)

| Check | Result |
| --- | --- |
| `npm run typecheck` | Pass |
| `npm run lint` | Pass (0 warnings) |
| `npm test` (40 unit tests: formula, zero reach, filters, totals consistency, CSV validation, insights, AI access rules, rate limiter) | Pass |
| `npm run build` (Next.js 16 production build) | Pass |
| `npm audit` (all dependencies) | 0 vulnerabilities |
| Scripted browser run on the production server in headless **Chromium**, 43 checks: filters, charts, every nav item, CSV import / append / persistence, posts search / sort / detail, insights, settings, corrupt-storage recovery, mobile layout | Pass |
| AI endpoint gating, run against a real production server with placeholder values (never a real key) | Pass: off with nothing set; off with a key only; off with key + opt-in but no access code in production; 401 without or with a wrong code; 403 for cross-site requests; 400 for bad bodies; 429 after the limit; correct code reaches the upstream call |
| Access-code screen in the browser (field shown, empty and wrong code rejected, no fake AI badge on failure) | Pass |
| Key, code and endpoint address absent from every client-side file and from the page HTML | Pass |
| Response headers (`X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`) | Pass |
| Stress: 5,000-row CSV imports in about 0.1 s, uses about 1.3 MB of the roughly 5 MB browser storage, dashboard, search and insights stay fast; 5,001 rows are rejected with a clear message | Pass |

## Not verified

- Other browsers (Firefox, Safari) and real phones. Only headless Chromium was used.
- Screen readers and a formal accessibility audit.
- The AI panel producing real output with a real API key. Only the access rules and the failure path were exercised,
  because no real key was used.
- Any deployment. Nothing has been published to GitHub or Vercel by the author of this project's build.

Bugs found and fixed during testing: an inverted date range was erased from the inputs before its warning could show;
the reset-demo dialog said "replaces your 0 imported posts" when there was no data; the AI endpoint turned on with a key
alone and had no login or rate limit (it now needs an explicit opt-in and, in production, an access code).

## Manual checklist (local)

Run `npm run dev`, open <http://localhost:3000>:

**First launch**
- [ ] Dashboard shows "Demo data" and 109 posts; average engagement is 5.22%
- [ ] Refresh: data is still there

**Dashboard**
- [ ] Platform filter = TikTok gives 18 posts, 7.97%
- [ ] "Last 7 days" narrows the posts; "All time" restores them
- [ ] From date later than To date shows a warning
- [ ] A filter with no matches shows an empty state with a working "Clear filters" button
- [ ] Metric toggle and Chart/Table view work on both charts; hover shows tooltips
- [ ] Clicking a top post opens details; Esc closes

**Upload**
- [ ] Sample CSV downloads; uploading it previews 10 rows and offers "Import 46 posts"
- [ ] After import the dashboard shows 46 posts, the demo badge is gone, and a refresh keeps the data
- [ ] `sample-posts-with-errors.csv`: 6 rows skipped (with row numbers), 4 rows with warnings, 6 importable
- [ ] A non-CSV file and a CSV with missing columns give clear messages
- [ ] Uploading again offers Replace / Add; adding the same file skips all duplicates

**Posts**
- [ ] Search, platform filter, sort by date / reach / engagement in both directions, pagination
- [ ] Row click opens details with the formula worked out

**AI Insights**
- [ ] "Local analysis" is labelled "Rule-based statistics, not an AI model"
- [ ] Best 3 / worst 3, patterns, suggestions and exactly 3 post ideas appear
- [ ] Without settings: "AI is not set up" and no AI badge anywhere

**Settings**
- [ ] Clear all data asks for confirmation; Cancel keeps data
- [ ] Reset demo data restores 109 posts

**Resilience**
- [ ] Corrupt the `ainlytics-ai:data:v1` value in DevTools → Local Storage and refresh: resets to demo with a notice
- [ ] Phone width: menu works, no sideways scroll

The checklist for the deployed website is in [DEPLOYMENT.md](./DEPLOYMENT.md).
