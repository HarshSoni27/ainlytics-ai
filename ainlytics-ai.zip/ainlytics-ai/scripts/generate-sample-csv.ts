/**
 * Generates the downloadable sample files in /public.
 * Run with: npm run generate:sample
 *
 * - sample-posts.csv          valid file (the last ~6 weeks of the demo data)
 * - sample-posts-with-errors.csv  deliberately broken rows, for testing validation
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { generateDemoPosts } from "../src/lib/demoData";

function csvCell(value: string | number): string {
  const s = String(value);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const HEADER = [
  "date",
  "platform",
  "content_type",
  "caption",
  "likes",
  "comments",
  "shares",
  "reach",
  "impressions",
];

const publicDir = join(process.cwd(), "public");
mkdirSync(publicDir, { recursive: true });

// ----- valid sample -----
const recent = generateDemoPosts().filter((p) => p.date >= "2026-10-09");
const lines = [HEADER.join(",")];
for (const p of recent) {
  lines.push(
    [
      p.date,
      p.platform,
      p.contentType,
      p.caption,
      p.likes,
      p.comments,
      p.shares,
      p.reach,
      p.impressions,
    ]
      .map(csvCell)
      .join(","),
  );
}
writeFileSync(join(publicDir, "sample-posts.csv"), `${lines.join("\n")}\n`);
console.log(`sample-posts.csv: ${recent.length} rows`);

// ----- file with deliberate problems -----
const bad = [
  HEADER.join(","),
  // good rows
  "2026-11-02,Instagram,Reel,Valid row to import,820,64,31,9400,12100",
  '2026-11-03,LinkedIn,Text,"Quoted caption, with a comma",140,22,18,3100,3900',
  // warnings (still imported)
  "2026-11-04,TikTok,Video,Zero reach post (rate can't be calculated),55,4,2,0,0",
  "2026-11-05,X,Text,,12,1,0,1800,2100",
  "2026-11-06,Facebook,Image,Missing impressions value,90,10,5,2600,",
  "2026-11-07,Instagram,Image,Interactions exceed reach,500,40,20,300,350",
  // errors (skipped)
  "not-a-date,Instagram,Image,Bad date,10,1,1,500,600",
  "2026-02-31,Instagram,Image,Impossible date,10,1,1,500,600",
  "2026-11-08,,Image,Missing platform,10,1,1,500,600",
  "2026-11-09,X,Text,Text where a number should be,abc,1,1,500,600",
  "2026-11-10,X,Text,Negative likes,-5,1,1,500,600",
  "2026-11-11,X,Text,Decimal comments,5,1.5,1,500,600",
];
writeFileSync(join(publicDir, "sample-posts-with-errors.csv"), `${bad.join("\n")}\n`);
console.log(`sample-posts-with-errors.csv: ${bad.length - 1} rows`);
